"""Độ chính xác (mAP) của YOLO khi ảnh bị nén JPEG ở nhiều mức chất lượng.

Để cân bằng "độ chính xác - độ trễ/băng thông": nén mạnh làm gói tin nhỏ và nhanh hơn nhưng có thể làm
giảm chất lượng phân tích. Script nén lại ảnh tập val ở từng mức rồi đo mAP bằng mô hình đã huấn luyện.

    python -m bench.accuracy_vs_jpeg --weights edge/weights/best.pt --data-dir data/yolo
"""
import argparse
import shutil
from pathlib import Path

import pandas as pd

from common.imaging import encode_jpeg, list_images, read_gray
from config import CLASSES


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--weights", default="edge/weights/best.pt")
    ap.add_argument("--data-dir", default="data/yolo")
    ap.add_argument("--qualities", type=int, nargs="+", default=[10, 30, 50, 70, 80, 95])
    ap.add_argument("--imgsz", type=int, default=224)
    ap.add_argument("--out", default="results/exp_accuracy_jpeg.csv")
    a = ap.parse_args()

    from ultralytics import YOLO
    model = YOLO(a.weights)
    data_dir = Path(a.data_dir)
    val_images = list_images(data_dir / "images" / "val")
    tmp_root = Path("runs/jpeg_tmp")
    rows = []
    for q in a.qualities:
        root = tmp_root / f"q{q}"
        if root.exists():
            shutil.rmtree(root)
        (root / "images" / "val").mkdir(parents=True)
        shutil.copytree(data_dir / "labels" / "val", root / "labels" / "val")
        total = 0
        for p in val_images:
            jpg = encode_jpeg(read_gray(p), q)
            total += len(jpg)
            (root / "images" / "val" / (p.stem + ".jpg")).write_bytes(jpg)
        names = "\n".join(f"  {i}: {c}" for i, c in enumerate(CLASSES))
        (root / "data.yaml").write_text(
            f"path: {root.resolve().as_posix()}\ntrain: images/val\nval: images/val\nnames:\n{names}\n")
        m = model.val(data=str(root / "data.yaml"), imgsz=a.imgsz, device="cpu", verbose=False, plots=False)
        rows.append({"jpeg_quality": q, "map50": float(m.box.map50), "map50_95": float(m.box.map),
                     "mean_jpeg_bytes": total / len(val_images)})
        print(f"quality={q}: mAP50={m.box.map50:.4f}  mean size={total / len(val_images):.0f} B")
    Path(a.out).parent.mkdir(exist_ok=True)
    pd.DataFrame(rows).to_csv(a.out, index=False)
    print(f"-> đã ghi {a.out}")


if __name__ == "__main__":
    main()
