"""Vẽ biểu đồ cho báo cáo từ các file results/exp_*.csv (mỗi điểm = trung bình các lần lặp, thanh sai số = độ lệch chuẩn).

    python -m bench.make_figures --results results --out results/figures
"""
import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import pandas as pd  # noqa: E402

LATENCY_TARGET_MS = 100.0


def _agg(df, x, cols):
    g = df.groupby(x)[cols].agg(["mean", "std"]).fillna(0)
    return g


def _line(ax, g, x_vals, col, label, marker="o"):
    ax.errorbar(x_vals, g[(col, "mean")], yerr=g[(col, "std")], marker=marker, capsize=3, label=label)


def fig_jpeg(df, out, acc=None):
    g = _agg(df, "value", ["e2e_ms_p95", "payload_bytes_mean", "edge_lat_mean"])
    fig, ax1 = plt.subplots(figsize=(7, 4.2))
    _line(ax1, g, g.index, "e2e_ms_p95", "Độ trễ e2e p95 (ms)")
    _line(ax1, g, g.index, "edge_lat_mean", "Độ trễ Edge trung bình (ms)", "s")
    ax1.axhline(LATENCY_TARGET_MS, color="red", ls="--", lw=1, label="Mục tiêu 100 ms")
    ax1.set_xlabel("Chất lượng JPEG"); ax1.set_ylabel("Độ trễ (ms)")
    ax2 = ax1.twinx()
    ax2.plot(g.index, g[("payload_bytes_mean", "mean")] / 1024, "g^--", label="Kích thước gói tin (KiB)")
    ax2.set_ylabel("KiB / gói tin")
    h1, l1 = ax1.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
    ax1.legend(h1 + h2, l1 + l2, fontsize=8, loc="upper left")
    ax1.set_title("Ảnh hưởng của mức nén JPEG tới độ trễ và dung lượng")
    fig.tight_layout(); fig.savefig(out / "fig_jpeg_latency_size.png", dpi=160); plt.close(fig)

    if acc is not None and len(acc):
        fig, ax = plt.subplots(figsize=(7, 4.2))
        ax.plot(acc["jpeg_quality"], acc["map50"], "o-", label="mAP50")
        ax.set_xlabel("Chất lượng JPEG"); ax.set_ylabel("mAP50"); ax.set_ylim(0, 1)
        ax2 = ax.twinx()
        ax2.plot(acc["jpeg_quality"], acc["mean_jpeg_bytes"] / 1024, "g^--", label="Kích thước ảnh (KiB)")
        ax2.set_ylabel("KiB / ảnh")
        h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
        ax.legend(h1 + h2, l1 + l2, fontsize=8, loc="lower right")
        ax.set_title("Cân bằng độ chính xác - dung lượng theo mức nén")
        fig.tight_layout(); fig.savefig(out / "fig_jpeg_accuracy.png", dpi=160); plt.close(fig)


def fig_workers(df, out):
    g = _agg(df, "value", ["e2e_ms_p95", "consumer_fps"])
    fig, ax1 = plt.subplots(figsize=(7, 4.2))
    _line(ax1, g, g.index, "e2e_ms_p95", "Độ trễ e2e p95 (ms)")
    ax1.axhline(LATENCY_TARGET_MS, color="red", ls="--", lw=1, label="Mục tiêu 100 ms")
    ax1.set_xlabel("Số worker"); ax1.set_ylabel("Độ trễ (ms)")
    ax2 = ax1.twinx(); ax2.plot(g.index, g[("consumer_fps", "mean")], "g^--", label="Thông lượng consumer (FPS)")
    ax2.set_ylabel("FPS")
    h1, l1 = ax1.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
    ax1.legend(h1 + h2, l1 + l2, fontsize=8); ax1.set_title("Ảnh hưởng của số worker")
    fig.tight_layout(); fig.savefig(out / "fig_workers.png", dpi=160); plt.close(fig)


def fig_buffer(df, out):
    g = _agg(df, "value", ["e2e_ms_p95", "bufwait_ms_p95", "max_buffer_depth"])
    fig, ax = plt.subplots(figsize=(7, 4.2))
    _line(ax, g, g.index, "e2e_ms_p95", "Độ trễ e2e p95 (ms)")
    _line(ax, g, g.index, "bufwait_ms_p95", "Chờ trong buffer p95 (ms)", "s")
    ax.axhline(LATENCY_TARGET_MS, color="red", ls="--", lw=1, label="Mục tiêu 100 ms")
    ax.set_xscale("log"); ax.set_xlabel("Kích thước buffer (ảnh)"); ax.set_ylabel("ms"); ax.legend(fontsize=8)
    ax.set_title("Ảnh hưởng của kích thước buffer tới độ trễ")
    fig.tight_layout(); fig.savefig(out / "fig_buffer.png", dpi=160); plt.close(fig)


def fig_fps(df, out):
    df = df.copy()
    # fps = 0 là "nhanh hết mức": vẽ tại FPS thực đạt được
    df["x"] = df.apply(lambda r: r["producer_fps"] if r["value"] == 0 else r["value"], axis=1)
    g = df.groupby("value").agg(x=("x", "mean"), p95=("e2e_ms_p95", "mean"), cons=("consumer_fps", "mean"),
                                lost=("lost_frames", "sum"), zero=("zero_drop", "all"),
                                cpu=("cpu_sys_mean", "mean")).sort_values("x")
    fig, ax = plt.subplots(figsize=(7, 4.2))
    ax.plot(g["x"], g["p95"], "o-", label="Độ trễ e2e p95 (ms)")
    bad = g[~g["zero"]]
    ax.scatter(bad["x"], bad["p95"], c="red", s=90, zorder=5, label="Có rớt khung")
    ax.axhline(LATENCY_TARGET_MS, color="red", ls="--", lw=1, label="Mục tiêu 100 ms")
    ax.set_xlabel("FPS đưa vào"); ax.set_ylabel("Độ trễ p95 (ms)"); ax.legend(fontsize=8)
    ax.set_title("Thông lượng và điểm bão hòa của hệ thống")
    fig.tight_layout(); fig.savefig(out / "fig_fps_saturation.png", dpi=160); plt.close(fig)

    fig, ax = plt.subplots(figsize=(7, 4.2))
    ax.plot(g["x"], g["cpu"], "o-", label="CPU toàn máy (%)")
    ax.set_xlabel("FPS đưa vào"); ax.set_ylabel("CPU (%)"); ax.legend(fontsize=8)
    ax.set_title("Mức tiêu tốn CPU theo tải")
    fig.tight_layout(); fig.savefig(out / "fig_fps_cpu.png", dpi=160); plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="results")
    ap.add_argument("--out", default="results/figures")
    a = ap.parse_args()
    res, out = Path(a.results), Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    made = []
    acc_path = res / "exp_accuracy_jpeg.csv"
    acc = pd.read_csv(acc_path) if acc_path.exists() else None
    for name, fn in (("jpeg", lambda d: fig_jpeg(d, out, acc)), ("workers", lambda d: fig_workers(d, out)),
                     ("buffer", lambda d: fig_buffer(d, out)), ("fps", lambda d: fig_fps(d, out))):
        p = res / f"exp_{name}.csv"
        if p.exists():
            fn(pd.read_csv(p))
            made.append(name)
    print(f"Đã vẽ biểu đồ cho: {made or 'không có dữ liệu'} -> {out}")


if __name__ == "__main__":
    main()
