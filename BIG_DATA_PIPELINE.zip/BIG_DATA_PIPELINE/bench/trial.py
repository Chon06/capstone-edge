"""Một "lần thử" (trial) đo hiệu năng: tạo topic riêng -> chạy consumer + producer -> thu số liệu.

Mỗi trial dùng topic mới (bench.xxxxxx) để các lần đo không ảnh hưởng nhau, xong thì xóa.
Các chỉ số trả về (một dict phẳng, dễ ghi CSV):
  - e2e_ms_*      : độ trễ từ lúc camera chụp -> consumer xử lý xong (mục tiêu < 100 ms)
  - edge_lat_*    : độ trễ xử lý ở Edge
  - transit_ms_*  : Edge xong -> consumer nhận (đường đi qua Kafka)
  - bufwait_ms_*  : thời gian chờ trong buffer
  - producer_fps / consumer_fps : thông lượng
  - zero_drop     : True nếu nhận đủ 100% ảnh duy nhất, không lỗi gửi, không rớt ở Edge
  - cpu_* / ram_* : tài nguyên (tiến trình Python này và toàn máy; thêm container nếu bật docker_stats)
  - edge_to_queue_mbps : băng thông tầng ứng dụng (tổng byte gói tin / thời gian), không phải số đo card mạng

Chú ý: Edge và consumer chạy chung 1 tiến trình Python nên cpu_proc_* là của cả hai cộng lại.
"""
import threading
import time
import uuid
from dataclasses import asdict, dataclass

from common.monitor import ResourceMonitor
from config import KAFKA_BOOTSTRAP
from edge.detectors import make_detector
from edge.edge_producer import run_producer
from queue_tier.consumer_buffer import run_consumer
from queue_tier.create_topic import create_topic, delete_topic


@dataclass
class TrialParams:
    images_dir: str = "data/stream_images"
    bootstrap: str = KAFKA_BOOTSTRAP
    frames: int = 500
    fps: float = 50.0            # 0 = phát nhanh hết mức
    cameras: int = 3
    partitions: int = 3
    jpeg_quality: int = 80
    detector: str = "classic"    # none | classic | yolo
    weights: str = "edge/weights/best.pt"
    yolo_threads: int | None = None
    linger_ms: int = 5
    on_full: str = "block"
    buffer_size: int = 1000
    workers: int = 2
    consumers: int = 1
    work_ms: float = 0.0         # thời gian "phân tích sâu" giả lập mỗi ảnh ở tầng sau
    docker_containers: tuple = ()  # vd ("kafka", "minio") để đo CPU/RAM container
    label: str = ""


def run_trial(p: TrialParams, detector=None) -> dict:
    detector = detector or make_detector(p.detector, p.weights, threads=p.yolo_threads)
    topic = f"bench.{uuid.uuid4().hex[:6]}"
    consumers = max(1, min(p.consumers, p.partitions))
    create_topic(p.bootstrap, topic, partitions=p.partitions)

    ready, holder = threading.Event(), {}
    est_s = (p.frames / p.fps) if p.fps > 0 else 30
    hard = est_s + 90

    def consume():
        holder["res"] = run_consumer(bootstrap=p.bootstrap, topic=topic, expected=p.frames,
                                     buffer_size=p.buffer_size, workers=p.workers, consumers=consumers,
                                     work_ms=p.work_ms, idle_timeout=15.0, hard_timeout=hard,
                                     ready_event=ready)

    th = threading.Thread(target=consume, daemon=True)
    th.start()
    try:
        if not ready.wait(60):
            raise RuntimeError("Consumer không nhận được partition nào sau 60 giây - kiểm tra Kafka")
        time.sleep(1.0)  # chờ ổn định để độ trễ của các ảnh đầu không bị cộng thời gian join group

        mon = ResourceMonitor(docker_containers=p.docker_containers).start()
        pstats = run_producer(bootstrap=p.bootstrap, topic=topic, images_dir=p.images_dir,
                              detector=detector, fps=p.fps, num_frames=p.frames, cameras=p.cameras,
                              jpeg_quality=p.jpeg_quality, linger_ms=p.linger_ms, on_full=p.on_full)
        th.join(timeout=hard)
        res_stats = mon.stop()
    finally:
        try:
            delete_topic(p.bootstrap, topic)
        except Exception:
            pass

    cstats = holder["res"]["stats"] if "res" in holder else {}
    unique = cstats.get("unique", 0)
    row = {**{f"param_{k}": v for k, v in asdict(p).items() if k not in ("docker_containers",)},
           **{f"prod_{k}" if k in ("duration_s",) else k: v for k, v in pstats.items()},
           **{f"cons_{k}" if k in ("duration_s", "buffer_size", "workers", "consumers") else k: v
              for k, v in cstats.items()},
           **res_stats}
    row["lost_frames"] = p.frames - unique
    row["zero_drop"] = bool(unique == p.frames and pstats["failed"] == 0 and pstats["dropped_edge"] == 0)
    row["edge_keeps_up"] = bool(p.fps <= 0 or pstats["producer_fps"] >= 0.95 * p.fps)
    return row
