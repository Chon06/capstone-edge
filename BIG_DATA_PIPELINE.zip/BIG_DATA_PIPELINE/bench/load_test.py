"""Thử nghiệm "bắn luồng" 1000+ ảnh liên tục vào hàng đợi và kiểm tra có mất ảnh không (Task 3.3).

    python -m bench.load_test --frames 1000 --fps 0            # bắn nhanh hết mức
    python -m bench.load_test --frames 2000 --fps 100 --workers 4 --work-ms 20

In ra: số ảnh gửi / nhận / mất / trùng, thông lượng, độ trễ (trung bình, p95, p99, max), tài nguyên.
"""
import argparse

from bench.trial import TrialParams, run_trial
from edge.detectors import make_detector


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--images", default="data/stream_images")
    ap.add_argument("--frames", type=int, default=1000)
    ap.add_argument("--fps", type=float, default=0.0, help="0 = nhanh hết mức")
    ap.add_argument("--cameras", type=int, default=3)
    ap.add_argument("--partitions", type=int, default=3)
    ap.add_argument("--detector", choices=["none", "classic", "yolo"], default="none")
    ap.add_argument("--weights", default="edge/weights/best.pt")
    ap.add_argument("--jpeg-quality", type=int, default=80)
    ap.add_argument("--buffer-size", type=int, default=1000)
    ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--work-ms", type=float, default=0.0)
    ap.add_argument("--docker-stats", action="store_true", help="đo thêm CPU/RAM container kafka, minio")
    a = ap.parse_args()

    p = TrialParams(images_dir=a.images, frames=a.frames, fps=a.fps, cameras=a.cameras,
                    partitions=a.partitions, jpeg_quality=a.jpeg_quality, detector=a.detector,
                    weights=a.weights, buffer_size=a.buffer_size, workers=a.workers, work_ms=a.work_ms,
                    docker_containers=("kafka", "minio") if a.docker_stats else ())
    row = run_trial(p, make_detector(a.detector, a.weights))

    print("\n================ KẾT QUẢ THỬ TẢI ================")
    print(f"Gửi (producer enqueued) : {row['enqueued']} / {row['frames_target']}")
    print(f"Nhận duy nhất           : {row['unique']}   | trùng: {row['duplicates']} | lỗi: {row['consumer_errors']}")
    print(f"Mất ảnh                 : {row['lost_frames']}   -> ZERO FRAME DROP = {row['zero_drop']}")
    print(f"Thông lượng producer    : {row['producer_fps']:.1f} FPS (mục tiêu {a.fps or 'tối đa'}); "
          f"Edge theo kịp lịch: {row['edge_keeps_up']}")
    print(f"Thông lượng consumer    : {row['consumer_fps']:.1f} FPS")
    print(f"Độ trễ e2e (ms)         : mean={row['e2e_ms_mean']:.1f} p50={row['e2e_ms_p50']:.1f} "
          f"p95={row['e2e_ms_p95']:.1f} p99={row['e2e_ms_p99']:.1f} max={row['e2e_ms_max']:.1f}")
    print(f"  - Edge xử lý          : mean={row['edge_lat_mean']:.2f} p95={row['edge_lat_p95']:.2f}")
    print(f"  - Qua Kafka           : mean={row['transit_ms_mean']:.1f} p95={row['transit_ms_p95']:.1f}")
    print(f"  - Chờ trong buffer    : mean={row['bufwait_ms_mean']:.1f} p95={row['bufwait_ms_p95']:.1f}")
    print(f"Buffer sâu nhất         : {row['max_buffer_depth']} / {a.buffer_size}")
    print(f"Băng thông Edge->Queue  : {row['edge_to_queue_mbps']:.2f} Mbps (tầng ứng dụng)")
    print(f"CPU toàn máy mean/max   : {row['cpu_sys_mean']:.0f}% / {row['cpu_sys_max']:.0f}%")
    print(f"RAM tiến trình tối đa   : {row['ram_proc_max_mb']:.0f} MB")


if __name__ == "__main__":
    main()
