"""Chạy các thí nghiệm thay đổi tham số (Nội dung 5): mỗi thí nghiệm đổi MỘT tham số, giữ nguyên phần còn lại.

    python -m bench.run_experiment --exp jpeg                      # mức nén ảnh ở Edge
    python -m bench.run_experiment --exp workers --work-ms 30      # số worker
    python -m bench.run_experiment --exp buffer  --work-ms 30      # kích thước buffer
    python -m bench.run_experiment --exp fps                       # tìm FPS tối đa không rớt khung
    python -m bench.run_experiment --exp all --repeat 3

Kết quả ghi vào results/exp_<tên>.csv (nối thêm), sau đó vẽ biểu đồ bằng: python -m bench.make_figures
"""
import argparse
from dataclasses import fields
from pathlib import Path

import pandas as pd

from bench.trial import TrialParams, run_trial
from edge.detectors import make_detector

# tên thí nghiệm -> (tham số được đổi, các giá trị thử)
EXPERIMENTS = {
    "jpeg": ("jpeg_quality", [30, 50, 70, 80, 95]),
    "workers": ("workers", [1, 2, 4, 8]),
    "buffer": ("buffer_size", [1, 10, 100, 1000]),
    "fps": ("fps", [10, 25, 50, 100, 200, 0]),
}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--exp", choices=[*EXPERIMENTS, "all"], required=True)
    ap.add_argument("--images", default="data/stream_images")
    ap.add_argument("--frames", type=int, default=500)
    ap.add_argument("--repeat", type=int, default=3, help="lặp lại mỗi cấu hình để tính trung bình/độ lệch")
    ap.add_argument("--detector", choices=["none", "classic", "yolo"], default="classic")
    ap.add_argument("--weights", default="edge/weights/best.pt")
    ap.add_argument("--yolo-threads", type=int, default=None)
    ap.add_argument("--base-fps", type=float, default=50.0)
    ap.add_argument("--work-ms", type=float, default=0.0,
                    help="thời gian phân tích giả lập/ảnh ở tầng sau (cần > 0 để thí nghiệm workers/buffer có ý nghĩa)")
    ap.add_argument("--docker-stats", action="store_true")
    ap.add_argument("--out-dir", default="results")
    a = ap.parse_args()

    detector = make_detector(a.detector, a.weights, threads=a.yolo_threads)
    base = dict(images_dir=a.images, frames=a.frames, fps=a.base_fps, detector=a.detector,
                weights=a.weights, yolo_threads=a.yolo_threads, work_ms=a.work_ms,
                docker_containers=("kafka", "minio") if a.docker_stats else ())
    names = list(EXPERIMENTS) if a.exp == "all" else [a.exp]
    out_dir = Path(a.out_dir)
    out_dir.mkdir(exist_ok=True)
    valid = {f.name for f in fields(TrialParams)}

    for name in names:
        param, values = EXPERIMENTS[name]
        assert param in valid
        rows = []
        for v in values:
            for rep in range(a.repeat):
                kw = {**base, param: v}
                if name in ("workers", "buffer", "fps") and a.work_ms == 0:
                    pass  # vẫn chạy được, nhưng worker/buffer sẽ ít ảnh hưởng nếu xử lý quá nhanh
                row = run_trial(TrialParams(**kw), detector)
                row.update({"experiment": name, "param": param, "value": v, "rep": rep})
                rows.append(row)
                print(f"[{name}] {param}={v} rep={rep}: e2e p95={row['e2e_ms_p95']:.1f}ms "
                      f"prod={row['producer_fps']:.0f}fps cons={row['consumer_fps']:.0f}fps "
                      f"lost={row['lost_frames']} zero_drop={row['zero_drop']}")
        path = out_dir / f"exp_{name}.csv"
        df = pd.DataFrame(rows)
        df.to_csv(path, mode="a", header=not path.exists(), index=False)
        print(f"-> đã ghi {path}")


if __name__ == "__main__":
    main()
