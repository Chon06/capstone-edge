"""Gói tin (message) chuẩn gửi qua Kafka - đúng theo schemas/frame_message_v1.schema.json."""
import base64
import json
import time
from pathlib import Path

from config import SCHEMA_VERSION

SCHEMA_PATH = Path(__file__).resolve().parents[1] / "schemas" / "frame_message_v1.schema.json"


def now_ms() -> int:
    """Epoch mili giây (UTC)."""
    return time.time_ns() // 1_000_000


def build_message(*, image_id, camera_id, frame_seq, ts_capture_ms, ts_edge_done_ms,
                  edge_latency_ms, detections, jpeg_bytes, jpeg_quality) -> dict:
    return {
        "schema_version": SCHEMA_VERSION,
        "image_id": image_id,
        "camera_id": camera_id,
        "frame_seq": int(frame_seq),
        "ts_capture_ms": int(ts_capture_ms),
        "ts_edge_done_ms": int(ts_edge_done_ms),
        "edge_latency_ms": round(float(edge_latency_ms), 3),
        "edge_status": "NG" if detections else "OK",
        "detections": detections,
        "image_codec": "jpeg",
        "jpeg_quality": int(jpeg_quality),
        "image_b64": base64.b64encode(jpeg_bytes).decode("ascii"),
    }


def serialize(msg: dict) -> bytes:
    return json.dumps(msg, separators=(",", ":")).encode("utf-8")


_validator = None


def validate_message(msg: dict) -> None:
    """Ném jsonschema.ValidationError nếu gói tin sai chuẩn."""
    global _validator
    if _validator is None:
        from jsonschema import Draft202012Validator
        _validator = Draft202012Validator(json.loads(SCHEMA_PATH.read_text(encoding="utf-8")))
    _validator.validate(msg)
