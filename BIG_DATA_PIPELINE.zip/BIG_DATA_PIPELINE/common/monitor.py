"""Đo tài nguyên (CPU/RAM) trong lúc chạy thí nghiệm.

- CPU/RAM toàn máy và của tiến trình Python hiện tại: dùng psutil.
- CPU/RAM của các container Docker (kafka, minio, spark...): dùng `docker stats`,
  chỉ khi truyền docker_containers=[...]. Lệnh này chậm (~1-2 giây/lần) nên lấy mẫu thưa hơn.
"""
import re
import subprocess
import threading
import time

import numpy as np
import psutil

_UNITS = {"b": 1, "kib": 1024, "mib": 1024 ** 2, "gib": 1024 ** 3,
          "kb": 1000, "mb": 1000 ** 2, "gb": 1000 ** 3}


def parse_mem(text: str) -> float:
    """'45.3MiB / 7.6GiB' -> số MiB đang dùng (45.3)."""
    used = text.split("/")[0].strip()
    m = re.match(r"([\d.]+)\s*([A-Za-z]+)", used)
    if not m:
        return float("nan")
    return float(m.group(1)) * _UNITS.get(m.group(2).lower(), 1) / 1024 ** 2


def parse_cpu(text: str) -> float:
    try:
        return float(text.strip().rstrip("%"))
    except ValueError:
        return float("nan")


class ResourceMonitor:
    def __init__(self, interval: float = 0.5, docker_containers=(), docker_interval: float = 2.0):
        self.interval = interval
        self.containers = list(docker_containers)
        self.docker_interval = docker_interval
        self._stop = threading.Event()
        self._thread = None
        self._sys_cpu, self._sys_mem, self._proc_cpu, self._proc_rss = [], [], [], []
        self._docker = {c: {"cpu": [], "mem": []} for c in self.containers}

    def start(self):
        self._proc = psutil.Process()
        self._proc.cpu_percent(None)
        psutil.cpu_percent(None)
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        return self

    def _sample_docker(self):
        try:
            out = subprocess.run(
                ["docker", "stats", "--no-stream", "--format", "{{.Name}};{{.CPUPerc}};{{.MemUsage}}",
                 *self.containers],
                capture_output=True, text=True, timeout=15).stdout
        except Exception:
            return
        for line in out.strip().splitlines():
            parts = line.split(";")
            if len(parts) == 3 and parts[0] in self._docker:
                self._docker[parts[0]]["cpu"].append(parse_cpu(parts[1]))
                self._docker[parts[0]]["mem"].append(parse_mem(parts[2]))

    def _run(self):
        last_docker = 0.0
        while not self._stop.wait(self.interval):
            self._sys_cpu.append(psutil.cpu_percent(None))
            self._sys_mem.append(psutil.virtual_memory().used / 1024 ** 2)
            self._proc_cpu.append(self._proc.cpu_percent(None))
            self._proc_rss.append(self._proc.memory_info().rss / 1024 ** 2)
            if self.containers and time.monotonic() - last_docker >= self.docker_interval:
                last_docker = time.monotonic()
                self._sample_docker()

    @staticmethod
    def _mean(v):
        return float(np.nanmean(v)) if len(v) else float("nan")

    @staticmethod
    def _max(v):
        return float(np.nanmax(v)) if len(v) else float("nan")

    def stop(self) -> dict:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=5)
        out = {
            "cpu_sys_mean": self._mean(self._sys_cpu), "cpu_sys_max": self._max(self._sys_cpu),
            "ram_sys_max_mb": self._max(self._sys_mem),
            "cpu_proc_mean": self._mean(self._proc_cpu), "cpu_proc_max": self._max(self._proc_cpu),
            "ram_proc_max_mb": self._max(self._proc_rss),
        }
        for name, d in self._docker.items():
            out[f"cpu_{name}_mean"] = self._mean(d["cpu"])
            out[f"ram_{name}_max_mb"] = self._max(d["mem"])
        return out
