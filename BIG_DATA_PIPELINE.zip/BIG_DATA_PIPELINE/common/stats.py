"""Thống kê độ trễ: trung bình, trung vị, p95, p99, max."""
import numpy as np


def summarize(values, prefix: str = "") -> dict:
    a = np.asarray(list(values), dtype=float)
    keys = ("mean", "p50", "p95", "p99", "max")
    if a.size == 0:
        return {f"{prefix}{k}": float("nan") for k in keys}
    return {
        f"{prefix}mean": float(a.mean()),
        f"{prefix}p50": float(np.percentile(a, 50)),
        f"{prefix}p95": float(np.percentile(a, 95)),
        f"{prefix}p99": float(np.percentile(a, 99)),
        f"{prefix}max": float(a.max()),
    }
