"""Đọc / mã hóa / giải mã ảnh. Dùng OpenCV nếu có, không thì dùng Pillow.

Ảnh NEU-DET là ảnh xám 200x200 nên toàn bộ pipeline làm việc với mảng
numpy 2 chiều (H, W) kiểu uint8.
"""
import io
from pathlib import Path

import numpy as np
from PIL import Image, ImageFilter

try:  # OpenCV là tùy chọn
    import cv2
except ImportError:  # pragma: no cover
    cv2 = None

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp"}


def list_images(folder):
    """Liệt kê ảnh (đệ quy), sắp xếp để thứ tự phát lại ổn định."""
    folder = Path(folder)
    files = [p for p in folder.rglob("*") if p.suffix.lower() in IMAGE_EXTS]
    return sorted(files)


def read_gray(path) -> np.ndarray:
    if cv2 is not None:
        img = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
        if img is None:
            raise IOError(f"Không đọc được ảnh: {path}")
        return img
    return np.asarray(Image.open(path).convert("L"), dtype=np.uint8)


def encode_jpeg(img: np.ndarray, quality: int) -> bytes:
    quality = int(quality)
    if cv2 is not None:
        ok, buf = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, quality])
        if not ok:
            raise ValueError("cv2.imencode thất bại")
        return buf.tobytes()
    bio = io.BytesIO()
    Image.fromarray(img).save(bio, format="JPEG", quality=quality)
    return bio.getvalue()


def decode_jpeg(data: bytes) -> np.ndarray:
    if cv2 is not None:
        img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_GRAYSCALE)
        if img is None:
            raise ValueError("cv2.imdecode thất bại")
        return img
    return np.asarray(Image.open(io.BytesIO(data)).convert("L"), dtype=np.uint8)


def gaussian_blur(img: np.ndarray, sigma: float) -> np.ndarray:
    if cv2 is not None:
        return cv2.GaussianBlur(img, (0, 0), sigma)
    return np.asarray(Image.fromarray(img).filter(ImageFilter.GaussianBlur(sigma)))
