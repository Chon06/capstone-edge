"""Cấu hình chung cho toàn bộ pipeline Edge -> Kafka -> Spark/MinIO.

Có thể ghi đè bằng biến môi trường (hữu ích khi chạy trong Docker,
ví dụ KAFKA_BOOTSTRAP=kafka:29092).
"""
import os

# --- Kafka ---
KAFKA_BOOTSTRAP = os.getenv("KAFKA_BOOTSTRAP", "localhost:9092")  # từ máy host
TOPIC = os.getenv("KAFKA_TOPIC", "defect.frames")
MAX_MESSAGE_BYTES = 5 * 1024 * 1024  # khớp KAFKA_MESSAGE_MAX_BYTES trong compose

# --- MinIO (S3 API) ---
MINIO_ENDPOINT = os.getenv("MINIO_ENDPOINT", "http://localhost:9000")
MINIO_ACCESS_KEY = os.getenv("MINIO_ACCESS_KEY", "minioadmin")
MINIO_SECRET_KEY = os.getenv("MINIO_SECRET_KEY", "minioadminpassword")
BUCKET_IMAGES = os.getenv("BUCKET_IMAGES", "defect-images")
BUCKET_ANALYSIS = os.getenv("BUCKET_ANALYSIS", "defect-analysis")

# --- Dữ liệu NEU-DET: 6 lớp lỗi bề mặt thép ---
CLASSES = [
    "crazing",
    "inclusion",
    "patches",
    "pitted_surface",
    "rolled_in_scale",
    "scratches",
]

SCHEMA_VERSION = "1.0"
