"""Tầng Điều phối: Kafka Consumer + bộ đệm giới hạn (buffer) + nhóm worker xử lý song song.

Luồng:  Kafka --poll--> [buffer có kích thước tối đa] --> worker 1..N --> ghi nhận kết quả

- Khi buffer đầy, luồng poll dừng lại => Kafka tự giữ ảnh ở phía broker (đây là cơ chế
  "hoãn xung"/back-pressure, KHÔNG mất ảnh).
- Số partition >= số consumer thì Kafka mới chia tải được cho tất cả consumer.
- Để đơn giản, offset được commit tự động (at-least-once, có thể trùng khi lỗi). Việc mất ảnh
  được kiểm bằng cách đếm image_id duy nhất đã nhận so với số ảnh đã gửi.

    python -m queue_tier.consumer_buffer --topic defect.frames --workers 4 --buffer-size 500
"""
import argparse
import base64
import json
import queue
import threading
import time
import uuid

from common.imaging import decode_jpeg
from common.stats import summarize
from config import KAFKA_BOOTSTRAP, MAX_MESSAGE_BYTES, TOPIC

# thứ tự cột của mỗi bản ghi kết quả
RECORD_FIELDS = ("image_id", "camera_id", "frame_seq", "ts_capture_ms", "ts_edge_done_ms",
                 "ts_polled_ms", "ts_start_ms", "ts_done_ms", "partition", "payload_bytes")


def run_consumer(*, bootstrap, topic, expected=None, group_id=None, buffer_size=1000, workers=2,
                 consumers=1, work_ms=0.0, decode_image=True, idle_timeout=10.0, hard_timeout=900.0,
                 offset_reset="earliest", ready_event=None) -> dict:
    """Chạy cho tới khi nhận đủ `expected` ảnh duy nhất, hoặc im lặng quá idle_timeout giây
    (sau khi đã nhận ít nhất 1 ảnh), hoặc quá hard_timeout. expected=None: chạy tới khi bị ngắt (Ctrl+C).

    work_ms: thời gian "phân tích sâu" giả lập mỗi ảnh (để thử khả năng chịu tải của worker).
    """
    from confluent_kafka import Consumer

    group_id = group_id or f"grp-{uuid.uuid4().hex[:8]}"
    buf = queue.Queue(maxsize=max(1, buffer_size))
    stop = threading.Event()
    lock = threading.Lock()
    records, seen = [], set()
    counters = {"errors": 0, "duplicates": 0, "max_depth": 0}
    last_progress = [time.monotonic()]
    assigned = [False] * consumers

    def poller(idx):
        c = Consumer({
            "bootstrap.servers": bootstrap, "group.id": group_id,
            "auto.offset.reset": offset_reset, "enable.auto.commit": True,
            "fetch.message.max.bytes": MAX_MESSAGE_BYTES + 1024 * 1024,
        })

        def on_assign(_c, parts):
            if parts:
                assigned[idx] = True
                if all(assigned) and ready_event is not None:
                    ready_event.set()

        c.subscribe([topic], on_assign=on_assign)
        try:
            while not stop.is_set():
                m = c.poll(0.2)
                if m is None:
                    continue
                if m.error():
                    with lock:
                        counters["errors"] += 1
                    continue
                item = (m.value(), time.time() * 1000, m.partition())
                while not stop.is_set():
                    try:
                        buf.put(item, timeout=0.2)  # buffer đầy -> dừng poll (back-pressure)
                        break
                    except queue.Full:
                        continue
                with lock:
                    counters["max_depth"] = max(counters["max_depth"], buf.qsize())
        finally:
            c.close()

    def worker():
        while not stop.is_set():
            try:
                value, t_poll, part = buf.get(timeout=0.2)
            except queue.Empty:
                continue
            t_start = time.time() * 1000
            try:
                msg = json.loads(value)
                if decode_image:
                    decode_jpeg(base64.b64decode(msg["image_b64"]))
                if work_ms > 0:
                    time.sleep(work_ms / 1000.0)
            except Exception:
                with lock:
                    counters["errors"] += 1
                continue
            t_done = time.time() * 1000
            with lock:
                if msg["image_id"] in seen:
                    counters["duplicates"] += 1
                else:
                    seen.add(msg["image_id"])
                records.append((msg["image_id"], msg["camera_id"], msg["frame_seq"], msg["ts_capture_ms"],
                                msg["ts_edge_done_ms"], t_poll, t_start, t_done, part, len(value)))
                last_progress[0] = time.monotonic()

    threads = [threading.Thread(target=poller, args=(i,), daemon=True) for i in range(consumers)]
    threads += [threading.Thread(target=worker, daemon=True) for _ in range(workers)]
    for t in threads:
        t.start()

    t_begin = time.monotonic()
    try:
        while True:
            time.sleep(0.05)
            with lock:
                n_unique = len(seen)
            if expected is not None and n_unique >= expected:
                break
            if n_unique > 0 and time.monotonic() - last_progress[0] > idle_timeout:
                break
            if time.monotonic() - t_begin > hard_timeout:
                break
    except KeyboardInterrupt:
        pass
    stop.set()
    for t in threads:
        t.join(timeout=5)

    return {"stats": compute_stats(records, counters, buffer_size, workers, consumers), "records": records}


def compute_stats(records, counters, buffer_size, workers, consumers) -> dict:
    n_unique = len({r[0] for r in records})
    st = {"received_total": len(records), "unique": n_unique, "duplicates": counters["duplicates"],
          "consumer_errors": counters["errors"], "max_buffer_depth": counters["max_depth"],
          "buffer_size": buffer_size, "workers": workers, "consumers": consumers}
    if records:
        first_poll = min(r[5] for r in records)
        last_done = max(r[7] for r in records)
        dur = max((last_done - first_poll) / 1000.0, 1e-9)
        st["consumer_duration_s"] = dur
        st["consumer_fps"] = n_unique / dur
        st["e2e_bytes_mbps"] = sum(r[9] for r in records) * 8 / 1e6 / dur
        st.update(summarize([r[7] - r[3] for r in records], "e2e_ms_"))          # chụp -> xử lý xong
        st.update(summarize([r[5] - r[4] for r in records], "transit_ms_"))      # Edge xong -> consumer nhận
        st.update(summarize([r[6] - r[5] for r in records], "bufwait_ms_"))      # chờ trong buffer
        st.update(summarize([r[7] - r[6] for r in records], "proc_ms_"))         # xử lý
    return st


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--bootstrap", default=KAFKA_BOOTSTRAP)
    ap.add_argument("--topic", default=TOPIC)
    ap.add_argument("--group", default=None)
    ap.add_argument("--expected", type=int, default=None)
    ap.add_argument("--buffer-size", type=int, default=1000)
    ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--consumers", type=int, default=1)
    ap.add_argument("--work-ms", type=float, default=0.0)
    ap.add_argument("--idle-timeout", type=float, default=10.0)
    ap.add_argument("--offset-reset", choices=["earliest", "latest"], default="earliest")
    a = ap.parse_args()
    res = run_consumer(bootstrap=a.bootstrap, topic=a.topic, expected=a.expected, group_id=a.group,
                       buffer_size=a.buffer_size, workers=a.workers, consumers=a.consumers,
                       work_ms=a.work_ms, idle_timeout=a.idle_timeout, offset_reset=a.offset_reset)
    print("\n=== KẾT QUẢ CONSUMER ===")
    for k, v in res["stats"].items():
        print(f"{k:>22}: {v:.3f}" if isinstance(v, float) else f"{k:>22}: {v}")


if __name__ == "__main__":
    main()
