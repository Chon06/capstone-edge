"""Tầng hàng đợi: tạo / xóa / mô tả topic Kafka (số partition, replication factor...).

    python -m queue_tier.create_topic --topic defect.frames --partitions 3 --replication 1
    python -m queue_tier.create_topic --topic defect.frames --describe
"""
import argparse
import time

from config import KAFKA_BOOTSTRAP, MAX_MESSAGE_BYTES, TOPIC


def _admin(bootstrap):
    from confluent_kafka.admin import AdminClient
    return AdminClient({"bootstrap.servers": bootstrap})


def topic_exists(bootstrap, topic) -> bool:
    return topic in _admin(bootstrap).list_topics(timeout=10).topics


def delete_topic(bootstrap, topic, wait_s: float = 15.0) -> None:
    admin = _admin(bootstrap)
    for fut in admin.delete_topics([topic], operation_timeout=15).values():
        fut.result()
    t0 = time.time()
    while time.time() - t0 < wait_s and topic in admin.list_topics(timeout=10).topics:
        time.sleep(0.3)


def create_topic(bootstrap, topic, partitions=3, replication=1, max_message_bytes=MAX_MESSAGE_BYTES,
                 retention_ms=None, recreate=False) -> None:
    from confluent_kafka.admin import NewTopic
    admin = _admin(bootstrap)
    if topic_exists(bootstrap, topic):
        if not recreate:
            print(f"Topic '{topic}' đã tồn tại (dùng --recreate để tạo lại).")
            return
        delete_topic(bootstrap, topic)
    cfg = {"max.message.bytes": str(max_message_bytes)}
    if retention_ms is not None:
        cfg["retention.ms"] = str(retention_ms)
    futures = admin.create_topics([NewTopic(topic, num_partitions=partitions,
                                            replication_factor=replication, config=cfg)])
    for fut in futures.values():
        fut.result()
    # chờ metadata lan truyền xong
    t0 = time.time()
    while time.time() - t0 < 15 and not topic_exists(bootstrap, topic):
        time.sleep(0.2)
    print(f"Đã tạo topic '{topic}': partitions={partitions}, replication={replication}")


def describe(bootstrap, topic) -> None:
    md = _admin(bootstrap).list_topics(topic=topic, timeout=10).topics.get(topic)
    if md is None:
        print(f"Không có topic '{topic}'")
        return
    print(f"Topic '{topic}' có {len(md.partitions)} partition:")
    for pid, p in sorted(md.partitions.items()):
        print(f"  partition {pid}: leader={p.leader} replicas={list(p.replicas)} isr={list(p.isrs)}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bootstrap", default=KAFKA_BOOTSTRAP)
    ap.add_argument("--topic", default=TOPIC)
    ap.add_argument("--partitions", type=int, default=3)
    ap.add_argument("--replication", type=int, default=1, help="máy đơn chỉ có 1 broker nên phải = 1")
    ap.add_argument("--retention-ms", type=int, default=None)
    ap.add_argument("--recreate", action="store_true")
    ap.add_argument("--describe", action="store_true")
    a = ap.parse_args()
    if a.describe:
        describe(a.bootstrap, a.topic)
        return
    create_topic(a.bootstrap, a.topic, a.partitions, a.replication, retention_ms=a.retention_ms,
                 recreate=a.recreate)
    describe(a.bootstrap, a.topic)


if __name__ == "__main__":
    main()
