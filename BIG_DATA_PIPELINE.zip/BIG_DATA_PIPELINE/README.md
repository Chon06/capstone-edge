# Pipeline phân tích ảnh lỗi công nghiệp thời gian thực: Edge → Kafka → Spark/MinIO

Bộ code này hiện thực 5 nội dung trong bảng task của đề tài, chạy trên Windows + Docker Desktop.
Hãy giải nén **đè vào** thư mục `E:\BIG_DATA_DOCKER` (file `docker-compose.yml` mới thay cho file cũ, các thư mục `schemas` giữ nguyên tên).

## 0. Bức tranh tổng thể (đọc trước khi chạy)

```
 [Camera giả lập] → [Edge: phát hiện lỗi + nén JPEG] → [Kafka topic] → [Consumer + buffer + worker]   ← "đường nhanh" (đo độ trễ < 100 ms)
                                                            └──────────→ [Spark Streaming] → [MinIO]    ← "đường phân tích sâu" (lưu ảnh, phân tích)
```

| Nội dung / Task trong bảng | File thực hiện | Lệnh chính |
|---|---|---|
| 2.1 Thu thập & gán nhãn dữ liệu | `data/prepare_neu_det.py` | `python -m data.prepare_neu_det --src <thư mục NEU-DET>` |
| 2.2 Script giả lập camera băng chuyền | `edge/camera_simulator.py` | (được gọi bởi producer) |
| 2.3 YOLOv8-nano / OpenCV lọc lỗi ở Edge | `edge/train_yolo.py`, `edge/detectors.py` | `python -m edge.train_yolo` |
| 2.4 Kafka Producer từ Edge | `edge/edge_producer.py` | `python -m edge.edge_producer` |
| 3.1 Topic, Partition, Replication | `queue_tier/create_topic.py` | `python -m queue_tier.create_topic` |
| 3.2 Consumer ở tầng điều phối (hoãn xung) | `queue_tier/consumer_buffer.py` | `python -m queue_tier.consumer_buffer` |
| 3.3 Bắn 1000+ ảnh liên tục vào Queue | `bench/load_test.py` | `python -m bench.load_test --frames 1000` |
| 4.1 MinIO + bucket | `lake/minio_setup.py` | `python -m lake.minio_setup` |
| 4.2 PySpark Streaming nhận từ Kafka | `spark/stream_job.py` | `docker compose --profile spark up -d --build spark` |
| 4.3 Phân tích sâu loại lỗi trên Spark | `spark/analysis_logic.py` | (chạy trong job Spark) |
| 4.4 Thông luồng toàn hệ thống | — | xem Bước 6 |
| 5.1 Công cụ đo Latency/FPS/CPU/RAM | `common/monitor.py`, `bench/trial.py` | (dùng trong các thí nghiệm) |
| 5.2 Đo độ trễ < 100 ms & tốc độ khung hình | `bench/run_experiment.py --exp fps` | xem Bước 7 |
| 5.3 Đổi Buffer, Worker, mức nén ảnh | `bench/run_experiment.py`, `bench/accuracy_vs_jpeg.py` | xem Bước 7 |
| 5.4 Biểu đồ & báo cáo hiệu năng | `bench/make_figures.py`, `docs/BAO_CAO_khung.md` | `python -m bench.make_figures` |

## 1. Cài đặt

```powershell
cd E:\BIG_DATA_DOCKER
docker compose up -d                       # Kafka + Kafka UI + MinIO
pip install -r requirements.txt            # phần lõi
pip install -r requirements-ml.txt         # phần AI cho Edge (nặng, chỉ cần khi huấn luyện/chạy YOLO)
```

Nếu `pip install ultralytics` lỗi trên Python 3.14, cài thêm Python 3.12 rồi dùng môi trường riêng:
`py -3.12 -m venv .venv` → `.venv\Scripts\activate` → cài lại 2 file requirements.

**Kiểm tra nhanh (không cần Kafka):** `python -m unittest tests.test_pipeline -v` → phải thấy `OK`.
(Các test dùng Kafka giả trong bộ nhớ để kiểm logic. Số liệu từ test **không** dùng cho báo cáo.)

## 2. Nội dung 2 — Dữ liệu, Edge, Producer

1. **Tải NEU-DET** (bộ ảnh lỗi bề mặt thép công khai, 1800 ảnh, 6 lớp: crazing, inclusion, patches, pitted_surface, rolled-in_scale, scratches) về và giải nén. Tìm bằng từ khóa "NEU surface defect database" (Kaggle/Github). Kaggle yêu cầu đăng nhập nên mình không tải hộ được.
2. Chuyển sang định dạng YOLO và chia train/val:
   ```powershell
   python -m data.prepare_neu_det --src "E:\datasets\NEU-DET" --out data/yolo
   ```
   Script tự tìm cặp ảnh + XML ở mọi thư mục con. Kết quả: `data/yolo/` và `data/stream_images/` (ảnh val cho camera giả lập).
   *Chưa có dữ liệu thật?* Chạy thử bằng ảnh giả lập: `python -m data.make_synthetic --out data/synthetic_neu` rồi trỏ `--src` vào đó. **Không dùng độ chính xác của dữ liệu giả lập trong báo cáo.**
3. **Huấn luyện YOLOv8-nano** (máy không GPU: ~30–90 phút cho 30 epoch; muốn nhanh hơn thì dùng Google Colab, copy `data/yolo` lên và chạy cùng lệnh):
   ```powershell
   python -m edge.train_yolo --data data/yolo/neu_det.yaml --epochs 30
   ```
   Cuối cùng in `mAP50` — ghi số này vào báo cáo. Trọng số lưu ở `edge/weights/best.pt`.
4. **Chạy Edge Producer** (cần topic ở Bước 3 trước):
   ```powershell
   python -m edge.edge_producer --detector yolo --weights edge/weights/best.pt --fps 25 --frames 500 --cameras 3
   ```
   Có 3 bộ phát hiện: `none` (không AI, để đo thuần hạ tầng), `classic` (lọc nhanh bằng xử lý ảnh, không cần huấn luyện), `yolo`.
   Dùng `--yolo-threads 1` hoặc `2` để giả lập thiết bị Edge yếu (ít nhân CPU).

## 3. Nội dung 3 — Topic, Consumer, thử tải

```powershell
python -m queue_tier.create_topic --topic defect.frames --partitions 3 --replication 1
python -m queue_tier.consumer_buffer --topic defect.frames --workers 4 --buffer-size 500   # terminal 1
python -m edge.edge_producer --detector classic --fps 50 --frames 1000                      # terminal 2
python -m bench.load_test --frames 1000 --fps 0                                            # thử tải tự động (tạo topic riêng)
```
- **Replication factor = 1** vì chỉ có 1 broker (máy đơn). Hãy nêu rõ điều này trong báo cáo; hệ thống thật dùng ≥ 3.
- **Partition**: muốn nhiều consumer chạy song song thì cần nhiều partition **và** nhiều khóa khác nhau. Message key là `camera_id`; nếu chỉ có 1 camera thì mọi ảnh vào cùng 1 partition. Vì thế mặc định dùng `--cameras 3`.
- **Buffer**: khi buffer đầy, consumer ngừng nhận → ảnh nằm lại trong Kafka (không mất). `load_test` in ra "ZERO FRAME DROP = True/False".

## 4. Nội dung 4 — MinIO và Spark

```powershell
python -m lake.minio_setup                                     # tạo 2 bucket và thử ghi/đọc
docker compose --profile spark up -d --build spark             # lần đầu build + tải gói Kafka cho Spark (vài phút)
docker compose logs -f spark                                   # chờ thấy "[batch N] ..." khi có dữ liệu
```
Spark đọc topic `defect.frames`, với mỗi ảnh: lưu ảnh gốc vào bucket `defect-images/<camera>/<ngày>/<image_id>.jpg`, tính phân tích sâu
(diện tích vùng lỗi, điểm nghiêm trọng LOW/MEDIUM/HIGH, độ sáng...) và ghi vào bucket `defect-analysis`:
`image_level/batch=*.jsonl` (từng ảnh) và `summary/batch=*.json` (theo camera + **cảnh báo** camera có tỉ lệ lỗi cao = gợi ý nguyên nhân gốc rễ ở mức thống kê).

Mặc định Spark chỉ đọc dữ liệu **mới** (`STARTING_OFFSETS=latest`): hãy bật Spark trước, rồi mới chạy Edge Producer.

## 5. Bước 6 — Thông luồng toàn hệ thống (Task 4.4)

```powershell
docker compose up -d
python -m queue_tier.create_topic --topic defect.frames
python -m lake.minio_setup
docker compose --profile spark up -d --build spark
python -m edge.edge_producer --detector yolo --weights edge/weights/best.pt --fps 25 --frames 300
python -m lake.minio_setup --list                              # phải thấy số object tăng
```
Mở MinIO Console http://localhost:9101 (minioadmin / minioadminpassword) để xem ảnh và file phân tích; Kafka UI http://localhost:8080 để xem topic.
Chụp màn hình các bước này làm bằng chứng demo.

## 6. Bước 7 — Nội dung 5: thí nghiệm hiệu năng

Mỗi thí nghiệm đổi **một** tham số, lặp 3 lần, ghi vào `results/exp_*.csv`:

```powershell
python -m bench.run_experiment --exp jpeg    --detector yolo --weights edge/weights/best.pt
python -m bench.run_experiment --exp workers --detector classic --work-ms 30
python -m bench.run_experiment --exp buffer  --detector classic --work-ms 30
python -m bench.run_experiment --exp fps     --detector yolo --weights edge/weights/best.pt --docker-stats
python -m bench.accuracy_vs_jpeg --weights edge/weights/best.pt          # mAP theo mức nén
python -m bench.make_figures                                              # vẽ biểu đồ vào results/figures
```
- `--work-ms 30` giả lập thời gian phân tích sâu 30 ms/ảnh ở tầng sau; không có nó thì thí nghiệm worker/buffer ít có ý nghĩa vì xử lý quá nhanh.
- `--docker-stats` đo thêm CPU/RAM của container `kafka`, `minio`.
- Thí nghiệm `fps` tìm **FPS tối đa không rớt khung**: điểm đỏ trên biểu đồ là cấu hình có rớt/mất ảnh.
- Muốn tải nặng hơn: tăng `--frames`, thêm `--yolo-threads 1`.

## 7. Những điều cần nêu trong báo cáo (để kết quả đứng vững khi bị hỏi)

1. **"Độ trễ < 100 ms" áp dụng cho đường nào?** Đường nhanh Edge → Kafka → consumer có thể đạt. Spark Structured Streaming chạy theo lô nhỏ (trigger 2 giây trong code) nên độ trễ đường Spark thường vài trăm ms tới vài giây. Hãy báo cáo **hai đường riêng** và nói rõ định nghĩa; nên thống nhất định nghĩa này với giảng viên hướng dẫn.
2. **Edge giả lập trên laptop**, không phải Raspberry Pi/Jetson. Ghi rõ CPU laptop, số luồng. Mục tiêu Edge < 15 ms phụ thuộc máy: số đo trên laptop mạnh không đại diện thiết bị biên thật.
3. **Cả hệ thống chạy trên 1 máy**: băng thông là loopback, nên `edge_to_queue_mbps` chỉ là băng thông tầng ứng dụng (tổng byte gói tin / thời gian), không phải số đo mạng nhà máy. Docker Desktop (WSL2) còn bị giới hạn CPU/RAM riêng — ghi lại cấu hình.
4. **NEU-DET không có ảnh "không lỗi"**, nên `edge_status` gần như luôn là NG và không đo được độ chính xác OK/NG. Độ chính xác được đo bằng mAP của việc phát hiện lỗi. Nếu cần OK/NG thật, cần thêm ảnh bề mặt thép bình thường.
5. **Đồng hồ**: mọi mốc thời gian lấy từ một máy nên so sánh được; độ phân giải ~1 ms (`ts_capture_ms` là số nguyên mili giây).
6. **Zero Frame Drop** trong code = nhận đủ 100% `image_id` duy nhất, không lỗi gửi, không rớt ở Edge. Offset consumer commit tự động (at-least-once), nên có thể có ảnh trùng — được đếm riêng (`duplicates`).
7. **Bộ lọc `classic`** chỉ bắt tốt lỗi có tương phản cục bộ rõ; bỏ sót vùng lớn, mờ (ví dụ `rolled_in_scale`). Đó là lý do cần YOLO ở Edge và là một điểm có thể đưa vào phần thảo luận.
8. Image MinIO dùng bản sao của bên thứ ba (`scnd/minio-mirror`), vì MinIO đã gỡ image chính thức. Đủ cho nghiên cứu; nên nêu trong phần hạn chế.

## 8. Lỗi thường gặp

| Triệu chứng | Cách xử lý |
|---|---|
| `kafka-topics` không nhận ra | Dùng `python -m queue_tier.create_topic` hoặc `docker exec kafka kafka-topics ...` |
| `ModuleNotFoundError: edge` | Phải chạy từ thư mục gốc dự án và dùng `python -m ...` (không chạy `python edge/xxx.py`) |
| Consumer "không nhận được partition" | Kafka chưa sẵn sàng: `docker compose ps`, `docker compose logs kafka --tail 50` |
| Spark không thấy dữ liệu | Spark đọc `latest`: bật Spark trước rồi mới gửi; hoặc đặt `STARTING_OFFSETS: earliest` trong compose |
| Build Spark lỗi tag image | Mở `spark/Dockerfile`, đổi tag `apache/spark:3.5.3-python3` sang tag python3 khác còn tồn tại |
| `fps` thí nghiệm báo `edge_keeps_up=False` | Edge không theo kịp FPS đặt ra → đó chính là giới hạn của Edge, không phải của Kafka |
