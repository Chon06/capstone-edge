"""Data Lake: tạo bucket trên MinIO, kiểm tra kết nối, liệt kê nội dung.

    python -m lake.minio_setup             # tạo 2 bucket: defect-images, defect-analysis
    python -m lake.minio_setup --list      # xem số object trong mỗi bucket
"""
import argparse

from config import BUCKET_ANALYSIS, BUCKET_IMAGES, MINIO_ACCESS_KEY, MINIO_ENDPOINT, MINIO_SECRET_KEY


def client(endpoint=MINIO_ENDPOINT):
    import boto3
    from botocore.client import Config
    return boto3.client("s3", endpoint_url=endpoint, aws_access_key_id=MINIO_ACCESS_KEY,
                        aws_secret_access_key=MINIO_SECRET_KEY, region_name="us-east-1",
                        config=Config(signature_version="s3v4", s3={"addressing_style": "path"}))


def ensure_buckets(s3, buckets=(BUCKET_IMAGES, BUCKET_ANALYSIS)):
    existing = {b["Name"] for b in s3.list_buckets()["Buckets"]}
    for b in buckets:
        if b in existing:
            print(f"Bucket '{b}' đã có")
        else:
            s3.create_bucket(Bucket=b)
            print(f"Đã tạo bucket '{b}'")


def count_objects(s3, bucket):
    n = size = 0
    for page in s3.get_paginator("list_objects_v2").paginate(Bucket=bucket):
        for obj in page.get("Contents", []):
            n += 1
            size += obj["Size"]
    return n, size


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--endpoint", default=MINIO_ENDPOINT)
    ap.add_argument("--list", action="store_true")
    a = ap.parse_args()
    s3 = client(a.endpoint)
    ensure_buckets(s3)
    if a.list:
        for b in (BUCKET_IMAGES, BUCKET_ANALYSIS):
            n, size = count_objects(s3, b)
            print(f"{b}: {n} object, {size / 1024:.1f} KiB")
    else:
        # thử ghi/đọc/xóa một object để chắc chắn S3 API hoạt động
        s3.put_object(Bucket=BUCKET_IMAGES, Key="_selftest.txt", Body=b"ok")
        assert s3.get_object(Bucket=BUCKET_IMAGES, Key="_selftest.txt")["Body"].read() == b"ok"
        s3.delete_object(Bucket=BUCKET_IMAGES, Key="_selftest.txt")
        print("MinIO S3 API hoạt động (ghi/đọc/xóa thử thành công).")


if __name__ == "__main__":
    main()
