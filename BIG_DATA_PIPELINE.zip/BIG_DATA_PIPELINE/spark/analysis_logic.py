"""Logic "phân tích sâu" cho từng ảnh (thuần Python, không phụ thuộc Spark/MinIO nên kiểm thử được).

Với mỗi gói tin từ Edge, tính:
  - kích thước ảnh, độ sáng trung bình, độ lệch chuẩn (đặc trưng thô của bề mặt)
  - tỉ lệ diện tích vùng lỗi so với ảnh (area_ratio) và điểm nghiêm trọng (severity_score)
  - mức độ nghiêm trọng LOW / MEDIUM / HIGH
Sau đó gom theo (camera, loại lỗi) để phát hiện camera/dây chuyền có tỉ lệ lỗi bất thường
(gợi ý nguyên nhân gốc rễ ở mức thống kê: lỗi nào tăng đột biến ở dây chuyền nào).
"""
from __future__ import annotations

import base64
import io
import time
from collections import defaultdict

SEVERITY_MEDIUM = 0.03   # severity_score >= ngưỡng này -> MEDIUM
SEVERITY_HIGH = 0.12     # severity_score >= ngưỡng này -> HIGH


def _area(b):
    return max(0.0, b[2] - b[0]) * max(0.0, b[3] - b[1])


def grade(score: float) -> str:
    if score >= SEVERITY_HIGH:
        return "HIGH"
    if score >= SEVERITY_MEDIUM:
        return "MEDIUM"
    return "LOW"


def image_stats(raw_jpeg: bytes):
    """Trả về (width, height, mean, std) của ảnh JPEG."""
    import numpy as np
    from PIL import Image
    img = Image.open(io.BytesIO(raw_jpeg)).convert("L")
    arr = np.asarray(img, dtype=np.float32)
    return img.size[0], img.size[1], float(arr.mean()), float(arr.std())


def analyze_record(rec: dict, raw_jpeg: bytes, s3_key: str, now_ms: int | None = None) -> dict:
    """rec: gói tin đã parse (dict). Trả về một dòng kết quả phân tích (không chứa ảnh)."""
    w, h, mean, std = image_stats(raw_jpeg)
    dets = rec.get("detections") or []
    img_area = float(w * h)
    area_ratio = sum(_area(d["bbox_xyxy"]) for d in dets) / img_area if img_area else 0.0
    severity = sum(d["confidence"] * _area(d["bbox_xyxy"]) / img_area for d in dets) if img_area else 0.0
    top = max(dets, key=lambda d: d["confidence"]) if dets else None
    now_ms = now_ms if now_ms is not None else int(time.time() * 1000)
    return {
        "image_id": rec["image_id"], "camera_id": rec["camera_id"], "frame_seq": rec["frame_seq"],
        "edge_status": rec["edge_status"], "n_defects": len(dets),
        "top_class": top["defect_class"] if top else None,
        "top_confidence": top["confidence"] if top else None,
        "defect_classes": sorted({d["defect_class"] for d in dets}),
        "area_ratio": round(area_ratio, 5), "severity_score": round(severity, 5),
        "severity": grade(severity) if dets else "NONE",
        "width": w, "height": h, "mean_intensity": round(mean, 2), "std_intensity": round(std, 2),
        "jpeg_bytes": len(raw_jpeg), "jpeg_quality": rec.get("jpeg_quality"),
        "edge_latency_ms": rec.get("edge_latency_ms"),
        "ts_capture_ms": rec["ts_capture_ms"], "ts_edge_done_ms": rec["ts_edge_done_ms"],
        "ts_spark_done_ms": now_ms, "e2e_latency_ms": now_ms - rec["ts_capture_ms"],
        "s3_key": s3_key,
    }


def decode_b64(rec: dict) -> bytes:
    return base64.b64decode(rec["image_b64"])


def summarize_batch(rows: list, min_frames: int = 10, alert_ng_ratio: float = 0.6) -> dict:
    """Gom một lô kết quả: đếm theo (camera, lỗi), tỉ lệ NG, cảnh báo camera có tỉ lệ NG cao."""
    per_cam = defaultdict(lambda: {"frames": 0, "ng": 0, "classes": defaultdict(int), "severity_sum": 0.0})
    for r in rows:
        c = per_cam[r["camera_id"]]
        c["frames"] += 1
        c["ng"] += r["edge_status"] == "NG"
        c["severity_sum"] += r["severity_score"]
        for cls in r["defect_classes"]:
            c["classes"][cls] += 1
    cams, alerts = {}, []
    for cam, c in sorted(per_cam.items()):
        ng_ratio = c["ng"] / c["frames"]
        dominant = max(c["classes"], key=c["classes"].get) if c["classes"] else None
        cams[cam] = {"frames": c["frames"], "ng": c["ng"], "ng_ratio": round(ng_ratio, 4),
                     "dominant_defect": dominant, "defect_counts": dict(c["classes"]),
                     "mean_severity": round(c["severity_sum"] / c["frames"], 5)}
        if c["frames"] >= min_frames and ng_ratio >= alert_ng_ratio:
            alerts.append({"camera_id": cam, "ng_ratio": round(ng_ratio, 4), "dominant_defect": dominant,
                           "message": f"{cam}: {ng_ratio:.0%} khung NG, lỗi chủ yếu '{dominant}' - kiểm tra dây chuyền/máy"})
    lat = sorted(r["e2e_latency_ms"] for r in rows)
    return {
        "frames": len(rows),
        "e2e_latency_ms": {"mean": sum(lat) / len(lat), "p95": lat[min(len(lat) - 1, int(0.95 * len(lat)))],
                           "max": lat[-1]} if lat else {},
        "per_camera": cams, "alerts": alerts,
    }
