"""Tầng Phân tích sâu & Data Lake: Spark Structured Streaming đọc Kafka -> lưu ảnh gốc vào MinIO
-> phân tích chi tiết -> ghi kết quả phân tích vào MinIO.

Chạy trong container (xem docker-compose.yml, profile "spark"):

    docker compose --profile spark up -d --build spark
    docker compose logs -f spark

Cấu hình qua biến môi trường (đã đặt sẵn trong compose): KAFKA_BOOTSTRAP, KAFKA_TOPIC, MINIO_ENDPOINT,
MINIO_ACCESS_KEY, MINIO_SECRET_KEY, STARTING_OFFSETS (latest|earliest), TRIGGER_SECONDS, MAX_OFFSETS_PER_TRIGGER.

Lưu ý khoa học: Structured Streaming xử lý theo lô nhỏ (micro-batch) nên độ trễ của đường Spark thường
vài trăm ms tới vài giây - cao hơn đường nhanh Edge->Kafka->consumer. Hãy báo cáo hai đường riêng.
"""
from __future__ import annotations

import json
import os
import time
from datetime import datetime, timezone

from pyspark.sql import Row, SparkSession
from pyspark.sql import types as T

import analysis_logic as AL

BOOT = os.getenv("KAFKA_BOOTSTRAP", "kafka:29092")
TOPIC = os.getenv("KAFKA_TOPIC", "defect.frames")
ENDPOINT = os.getenv("MINIO_ENDPOINT", "http://minio:9000")
ACCESS = os.getenv("MINIO_ACCESS_KEY", "minioadmin")
SECRET = os.getenv("MINIO_SECRET_KEY", "minioadminpassword")
BUCKET_IMAGES = os.getenv("BUCKET_IMAGES", "defect-images")
BUCKET_ANALYSIS = os.getenv("BUCKET_ANALYSIS", "defect-analysis")
STARTING = os.getenv("STARTING_OFFSETS", "latest")
TRIGGER_S = os.getenv("TRIGGER_SECONDS", "2")
MAX_OFFSETS = os.getenv("MAX_OFFSETS_PER_TRIGGER", "500")

DET = T.ArrayType(T.StructType([
    T.StructField("defect_class", T.StringType()),
    T.StructField("confidence", T.DoubleType()),
    T.StructField("bbox_xyxy", T.ArrayType(T.DoubleType())),
]))
MSG_SCHEMA = T.StructType([
    T.StructField("schema_version", T.StringType()), T.StructField("image_id", T.StringType()),
    T.StructField("camera_id", T.StringType()), T.StructField("frame_seq", T.LongType()),
    T.StructField("ts_capture_ms", T.LongType()), T.StructField("ts_edge_done_ms", T.LongType()),
    T.StructField("edge_latency_ms", T.DoubleType()), T.StructField("edge_status", T.StringType()),
    T.StructField("detections", DET), T.StructField("image_codec", T.StringType()),
    T.StructField("jpeg_quality", T.IntegerType()), T.StructField("image_b64", T.StringType()),
])


def s3_client():
    import boto3
    from botocore.client import Config
    return boto3.client("s3", endpoint_url=ENDPOINT, aws_access_key_id=ACCESS, aws_secret_access_key=SECRET,
                        config=Config(signature_version="s3v4", s3={"addressing_style": "path"}),
                        region_name="us-east-1")


def process_partition(rows):
    """Chạy trên executor: lưu ảnh gốc vào MinIO và phân tích từng ảnh."""
    s3 = s3_client()
    out = []
    for r in rows:
        rec = r.asDict(recursive=True)
        raw = AL.decode_b64(rec)
        day = datetime.fromtimestamp(rec["ts_capture_ms"] / 1000, tz=timezone.utc).strftime("%Y-%m-%d")
        key = f"{rec['camera_id']}/{day}/{rec['image_id']}.jpg"
        s3.put_object(Bucket=BUCKET_IMAGES, Key=key, Body=raw, ContentType="image/jpeg")
        out.append(AL.analyze_record(rec, raw, key))
    return out


def process_batch(df, batch_id):
    rows = df.rdd.mapPartitions(process_partition).collect()  # kết quả nhỏ (không chứa ảnh)
    if not rows:
        return
    summary = AL.summarize_batch(rows)
    summary.update({"batch_id": batch_id, "written_at_ms": int(time.time() * 1000)})
    s3 = s3_client()
    body = "\n".join(json.dumps(r, ensure_ascii=False) for r in rows).encode("utf-8")
    s3.put_object(Bucket=BUCKET_ANALYSIS, Key=f"image_level/batch={batch_id:06d}.jsonl", Body=body)
    s3.put_object(Bucket=BUCKET_ANALYSIS, Key=f"summary/batch={batch_id:06d}.json",
                  Body=json.dumps(summary, ensure_ascii=False, indent=2).encode("utf-8"))
    lat = summary["e2e_latency_ms"]
    print(f"[batch {batch_id}] {summary['frames']} ảnh | e2e mean={lat.get('mean', 0):.0f}ms "
          f"p95={lat.get('p95', 0):.0f}ms | cảnh báo: {len(summary['alerts'])}", flush=True)
    for a in summary["alerts"]:
        print("   !!", a["message"], flush=True)


def main():
    spark = (SparkSession.builder.appName("defect-deep-analysis")
             .config("spark.sql.shuffle.partitions", "3").getOrCreate())
    spark.sparkContext.setLogLevel("WARN")
    raw = (spark.readStream.format("kafka")
           .option("kafka.bootstrap.servers", BOOT).option("subscribe", TOPIC)
           .option("startingOffsets", STARTING).option("maxOffsetsPerTrigger", MAX_OFFSETS)
           .option("failOnDataLoss", "false").load())
    from pyspark.sql import functions as F
    parsed = raw.select(F.from_json(F.col("value").cast("string"), MSG_SCHEMA).alias("m")).select("m.*")
    q = (parsed.writeStream.foreachBatch(process_batch)
         .trigger(processingTime=f"{TRIGGER_S} seconds")
         .option("checkpointLocation", "/tmp/checkpoints/defect").start())
    q.awaitTermination()


if __name__ == "__main__":
    main()
