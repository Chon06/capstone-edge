"""Kafka giả lập trong bộ nhớ (chỉ dùng để kiểm thử logic, KHÔNG đo hiệu năng thật).

Gọi install() để thay thế module `confluent_kafka` bằng bản giả có cùng giao diện
mà pipeline sử dụng (Producer, Consumer, AdminClient, NewTopic).
"""
import sys
import threading
import time
import types
import zlib

_LOCK = threading.RLock()
TOPICS = {}  # tên -> list các partition, mỗi partition là list (key, value, ts)


class _Fut:
    def __init__(self, exc=None):
        self.exc = exc

    def result(self):
        if self.exc:
            raise self.exc


class NewTopic:
    def __init__(self, topic, num_partitions=1, replication_factor=1, config=None):
        self.topic, self.num_partitions = topic, num_partitions


class _PartMeta:
    leader, replicas, isrs = 1, [1], [1]


class _TopicMeta:
    def __init__(self, n):
        self.partitions = {i: _PartMeta() for i in range(n)}


class _Md:
    def __init__(self, topics):
        self.topics = topics


class AdminClient:
    def __init__(self, conf):
        pass

    def create_topics(self, new_topics, **kw):
        out = {}
        with _LOCK:
            for nt in new_topics:
                TOPICS[nt.topic] = [[] for _ in range(nt.num_partitions)]
                out[nt.topic] = _Fut()
        return out

    def delete_topics(self, topics, **kw):
        with _LOCK:
            for t in topics:
                TOPICS.pop(t, None)
        return {t: _Fut() for t in topics}

    def list_topics(self, topic=None, timeout=None):
        with _LOCK:
            return _Md({n: _TopicMeta(len(p)) for n, p in TOPICS.items() if topic in (None, n)})


class Producer:
    def __init__(self, conf):
        self._pending = []
        self._rr = 0

    def produce(self, topic, key=None, value=None, on_delivery=None):
        with _LOCK:
            parts = TOPICS[topic]
            if key is not None:
                k = key.encode() if isinstance(key, str) else key
                p = zlib.crc32(k) % len(parts)
            else:
                p = self._rr % len(parts)
                self._rr += 1
            parts[p].append((key, value, time.time()))
        self._pending.append(on_delivery)

    def poll(self, timeout=0):
        self._drain()
        return 0

    def flush(self, timeout=None):
        self._drain()

    def _drain(self):
        pend, self._pending = self._pending, []
        for cb in pend:
            if cb:
                cb(None, None)


class TopicPartition:
    def __init__(self, topic, partition):
        self.topic, self.partition = topic, partition


class _Msg:
    def __init__(self, topic, part, key, value, ts):
        self._t, self._p, self._k, self._v, self._ts = topic, part, key, value, ts

    def error(self):
        return None

    def value(self):
        return self._v

    def key(self):
        return self._k

    def partition(self):
        return self._p

    def topic(self):
        return self._t

    def timestamp(self):
        return (1, int(self._ts * 1000))


_GROUPS = {}  # (group, topic) -> list các consumer đã đăng ký


class Consumer:
    def __init__(self, conf):
        self.group = conf["group.id"]
        self.topic = None
        self.offsets = {}
        self._assigned = False
        self._on_assign = None
        self._rr = 0

    def subscribe(self, topics, on_assign=None):
        self.topic = topics[0]
        self._on_assign = on_assign
        with _LOCK:
            _GROUPS.setdefault((self.group, self.topic), []).append(self)

    def _my_partitions(self):
        with _LOCK:
            members = _GROUPS[(self.group, self.topic)]
            n = len(TOPICS[self.topic])
            return [p for p in range(n) if p % len(members) == members.index(self)]

    def poll(self, timeout=1.0):
        deadline = time.time() + timeout
        while True:
            with _LOCK:
                if self.topic in TOPICS:
                    mine = self._my_partitions()
                    if not self._assigned:
                        self._assigned = True
                        if self._on_assign:
                            self._on_assign(self, [TopicPartition(self.topic, p) for p in mine])
                    for i in range(len(mine)):
                        p = mine[(self._rr + i) % len(mine)]
                        off = self.offsets.get(p, 0)
                        part = TOPICS[self.topic][p]
                        if off < len(part):
                            self.offsets[p] = off + 1
                            self._rr += 1
                            k, v, ts = part[off]
                            return _Msg(self.topic, p, k, v, ts)
            if time.time() >= deadline:
                return None
            time.sleep(0.002)

    def close(self):
        with _LOCK:
            lst = _GROUPS.get((self.group, self.topic), [])
            if self in lst:
                lst.remove(self)


def install():
    """Thay confluent_kafka thật bằng bản giả trong sys.modules."""
    ck = types.ModuleType("confluent_kafka")
    ck.Producer, ck.Consumer = Producer, Consumer
    admin = types.ModuleType("confluent_kafka.admin")
    admin.AdminClient, admin.NewTopic = AdminClient, NewTopic
    ck.admin = admin
    sys.modules["confluent_kafka"] = ck
    sys.modules["confluent_kafka.admin"] = admin
