"""Kiểm thử logic không cần Kafka/Spark/MinIO thật. Chạy:  python -m unittest tests.test_pipeline -v

Phần Kafka dùng bản giả lập trong bộ nhớ (tests/fake_kafka.py) nên KHÔNG kiểm chứng hiệu năng Kafka thật.
"""
import shutil
import tempfile
import time
import unittest
from pathlib import Path

import numpy as np
from PIL import Image

from tests import fake_kafka

fake_kafka.install()  # phải gọi trước khi import các module dùng confluent_kafka

from bench.trial import TrialParams, run_trial  # noqa: E402
from common import imaging  # noqa: E402
from common.message import build_message, serialize, validate_message  # noqa: E402
from common.monitor import parse_cpu, parse_mem  # noqa: E402
from common.stats import summarize  # noqa: E402
from data import make_synthetic, prepare_neu_det  # noqa: E402
from edge.camera_simulator import CameraSimulator  # noqa: E402
from edge.detectors import ClassicDetector, make_detector  # noqa: E402
from spark import analysis_logic as AL  # noqa: E402


class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = Path(tempfile.mkdtemp())
        cls.syn = cls.tmp / "syn"
        import sys
        old = sys.argv
        sys.argv = ["x", "--out", str(cls.syn), "--per-class", "10"]
        make_synthetic.main()
        sys.argv = old

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp, ignore_errors=True)


class TestData(Base):
    def test_prepare_yolo(self):
        import sys
        out, stream = self.tmp / "yolo", self.tmp / "stream"
        old = sys.argv
        sys.argv = ["x", "--src", str(self.syn), "--out", str(out), "--stream-dir", str(stream)]
        prepare_neu_det.main()
        sys.argv = old
        tr = list((out / "images" / "train").glob("*.jpg"))
        va = list((out / "images" / "val").glob("*.jpg"))
        self.assertEqual(len(tr) + len(va), 60)
        self.assertEqual(len(va), 12)  # 20% của mỗi lớp (2/10) x 6
        self.assertEqual(len(list(stream.glob("*.jpg"))), 12)
        seen_cls = set()
        for lab in (out / "labels" / "train").glob("*.txt"):
            for line in lab.read_text().splitlines():
                c, *vals = line.split()
                seen_cls.add(int(c))
                self.assertTrue(all(0.0 <= float(v) <= 1.0 for v in vals))
        self.assertEqual(seen_cls, set(range(6)))  # đủ 6 lớp, 'rolled-in_scale' được chuẩn hóa
        self.assertIn("rolled_in_scale", (out / "neu_det.yaml").read_text())


class TestCore(Base):
    def test_message_matches_schema(self):
        jpg = imaging.encode_jpeg(np.full((200, 200), 100, np.uint8), 80)
        msg = build_message(image_id="IMG_000001", camera_id="CAM_LINE_01", frame_seq=1, ts_capture_ms=1,
                            ts_edge_done_ms=2, edge_latency_ms=1.234567, jpeg_quality=80, jpeg_bytes=jpg,
                            detections=[{"defect_class": "crazing", "confidence": 0.9,
                                         "bbox_xyxy": [1, 2, 30, 40]}])
        validate_message(msg)
        self.assertEqual(msg["edge_status"], "NG")
        self.assertEqual(msg["edge_latency_ms"], 1.235)
        msg["detections"] = []
        self.assertEqual(build_message(**{**{k: msg[k] for k in ()}, "image_id": "a", "camera_id": "c",
                                          "frame_seq": 0, "ts_capture_ms": 0, "ts_edge_done_ms": 0,
                                          "edge_latency_ms": 0, "detections": [], "jpeg_bytes": jpg,
                                          "jpeg_quality": 80})["edge_status"], "OK")
        bad = dict(msg); bad.pop("image_b64")
        with self.assertRaises(Exception):
            validate_message(bad)
        self.assertIsInstance(serialize(msg), bytes)

    def test_jpeg_roundtrip_and_size_vs_quality(self):
        img = np.asarray(Image.open(next(self.syn.rglob("*.jpg"))).convert("L"))
        small, big = imaging.encode_jpeg(img, 20), imaging.encode_jpeg(img, 95)
        self.assertLess(len(small), len(big))
        self.assertEqual(imaging.decode_jpeg(big).shape, img.shape)

    def test_camera_simulator_pacing_and_cameras(self):
        sim = CameraSimulator(self.syn, fps=100, num_frames=50, cameras=3)
        t0 = time.perf_counter()
        frames = list(sim)
        dt = time.perf_counter() - t0
        self.assertGreater(dt, 0.45)
        self.assertLess(dt, 0.9)
        self.assertEqual([f.camera_id for f in frames[:4]], ["CAM_LINE_01", "CAM_LINE_02", "CAM_LINE_03", "CAM_LINE_01"])
        self.assertEqual(frames[3].frame_seq, 2)
        self.assertEqual(len({f.image_id for f in frames}), 50)
        t0 = time.perf_counter()
        list(CameraSimulator(self.syn, fps=0, num_frames=200))
        self.assertLess(time.perf_counter() - t0, 0.5)

    def test_classic_detector_finds_defect_not_clean(self):
        det = ClassicDetector()
        rng = np.random.default_rng(1)
        clean = np.clip(rng.normal(125, 8, (200, 200)), 0, 255).astype(np.uint8)
        self.assertEqual(det.detect(clean), [])
        img, box = make_synthetic.make_image("patches", np.random.default_rng(2))
        res = det.detect(np.asarray(img))
        self.assertEqual(len(res), 1)
        x1, y1, x2, y2 = res[0]["bbox_xyxy"]
        self.assertLess(abs(x1 - box[0]), 15)
        self.assertLess(abs(y2 - box[3]), 15)

    def test_make_detector_requires_weights(self):
        with self.assertRaises(ValueError):
            make_detector("yolo")

    def test_stats_and_parsers(self):
        s = summarize([1, 2, 3, 4, 100], "x_")
        self.assertEqual(s["x_max"], 100)
        self.assertEqual(s["x_p50"], 3)
        self.assertTrue(np.isnan(summarize([], "y_")["y_mean"]))
        self.assertAlmostEqual(parse_mem("512MiB / 7.6GiB"), 512)
        self.assertAlmostEqual(parse_mem("1.5GiB / 7.6GiB"), 1536)
        self.assertEqual(parse_cpu("12.5%"), 12.5)


class TestTrial(Base):
    def _run(self, **kw):
        base = dict(images_dir=str(self.syn), frames=300, fps=0, cameras=3, partitions=3, detector="classic",
                    bootstrap="fake")
        base.update(kw)
        return run_trial(TrialParams(**base))

    def test_zero_loss_unthrottled(self):
        r = self._run()
        self.assertEqual(r["unique"], 300)
        self.assertEqual(r["lost_frames"], 0)
        self.assertEqual(r["duplicates"], 0)
        self.assertTrue(r["zero_drop"])
        for k in ("e2e_ms_p95", "edge_lat_mean", "transit_ms_p95", "consumer_fps", "cpu_sys_mean",
                  "edge_to_queue_mbps", "ram_proc_max_mb"):
            self.assertIn(k, r)
            self.assertFalse(np.isnan(r[k]), k)
        # bộ lọc 'classic' bắt được ~4/6 loại lỗi giả lập (bỏ sót vùng lớn, tương phản thấp như rolled_in_scale)
        self.assertGreater(r["ng_frames"], 150)
        self.assertLess(r["ng_frames"], 300)

    def test_all_partitions_used_with_multiple_cameras(self):
        import collections
        r = self._run(frames=90, cameras=3)
        self.assertTrue(r["zero_drop"])

    def test_workers_increase_throughput_when_work_is_slow(self):
        slow = self._run(frames=120, workers=1, work_ms=10, detector="none")
        fast = self._run(frames=120, workers=4, work_ms=10, detector="none")
        self.assertGreater(fast["consumer_fps"], slow["consumer_fps"] * 2)
        self.assertGreater(slow["e2e_ms_p95"], fast["e2e_ms_p95"])

    def test_small_buffer_backpressure_still_zero_loss(self):
        r = self._run(frames=150, workers=1, work_ms=5, buffer_size=2, detector="none")
        self.assertTrue(r["zero_drop"])
        self.assertLessEqual(r["max_buffer_depth"], 2)


class TestAnalysis(Base):
    def _rec(self, cam, dets, jpg, i):
        return {"image_id": f"IMG_{i}", "camera_id": cam, "frame_seq": i, "edge_status": "NG" if dets else "OK",
                "detections": dets, "jpeg_quality": 80, "edge_latency_ms": 5.0,
                "ts_capture_ms": 1000, "ts_edge_done_ms": 1010}

    def test_analyze_and_summarize(self):
        jpg = imaging.encode_jpeg(np.full((200, 200), 120, np.uint8), 80)
        big = [{"defect_class": "patches", "confidence": 0.9, "bbox_xyxy": [0, 0, 100, 100]}]   # 25% diện tích
        small = [{"defect_class": "scratches", "confidence": 0.5, "bbox_xyxy": [0, 0, 10, 10]}]  # 0.25%
        r_big = AL.analyze_record(self._rec("A", big, jpg, 1), jpg, "k1", now_ms=1100)
        r_small = AL.analyze_record(self._rec("A", small, jpg, 2), jpg, "k2", now_ms=1100)
        r_ok = AL.analyze_record(self._rec("B", [], jpg, 3), jpg, "k3", now_ms=1100)
        self.assertEqual(r_big["severity"], "HIGH")
        self.assertEqual(r_small["severity"], "LOW")
        self.assertEqual(r_ok["severity"], "NONE")
        self.assertAlmostEqual(r_big["area_ratio"], 0.25)
        self.assertEqual(r_big["e2e_latency_ms"], 100)
        self.assertEqual((r_big["width"], r_big["height"]), (200, 200))
        rows = [AL.analyze_record(self._rec("A", big, jpg, i), jpg, "k", now_ms=1100) for i in range(12)]
        rows += [AL.analyze_record(self._rec("B", [], jpg, 100 + i), jpg, "k", now_ms=1100) for i in range(12)]
        s = AL.summarize_batch(rows)
        self.assertEqual(s["per_camera"]["A"]["ng_ratio"], 1.0)
        self.assertEqual(s["per_camera"]["A"]["dominant_defect"], "patches")
        self.assertEqual(s["per_camera"]["B"]["ng_ratio"], 0.0)
        self.assertEqual([a["camera_id"] for a in s["alerts"]], ["A"])


class TestFigures(unittest.TestCase):
    def test_figures_render_from_csv_schema(self):
        """Kiểm tra make_figures chạy được với đúng tên cột mà run_trial tạo ra (dữ liệu ở đây là GIẢ, chỉ để kiểm hàm vẽ)."""
        import pandas as pd
        from bench import make_figures
        tmp = Path(tempfile.mkdtemp())
        base = dict(e2e_ms_p95=50.0, payload_bytes_mean=20000.0, edge_lat_mean=5.0, consumer_fps=50.0,
                    bufwait_ms_p95=3.0, max_buffer_depth=4, producer_fps=50.0, lost_frames=0, zero_drop=True,
                    cpu_sys_mean=30.0)
        for name, vals in (("jpeg", [30, 80]), ("workers", [1, 2]), ("buffer", [1, 10]), ("fps", [10, 0])):
            pd.DataFrame([{**base, "value": v, "rep": r} for v in vals for r in range(2)]).to_csv(
                tmp / f"exp_{name}.csv", index=False)
        pd.DataFrame({"jpeg_quality": [30, 80], "map50": [0.5, 0.6], "map50_95": [0.3, 0.4],
                      "mean_jpeg_bytes": [5000, 9000]}).to_csv(tmp / "exp_accuracy_jpeg.csv", index=False)
        import sys
        old = sys.argv
        sys.argv = ["x", "--results", str(tmp), "--out", str(tmp / "fig")]
        make_figures.main()
        sys.argv = old
        pngs = {p.name for p in (tmp / "fig").glob("*.png")}
        self.assertEqual(pngs, {"fig_jpeg_latency_size.png", "fig_jpeg_accuracy.png", "fig_workers.png",
                                "fig_buffer.png", "fig_fps_saturation.png", "fig_fps_cpu.png"})
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
