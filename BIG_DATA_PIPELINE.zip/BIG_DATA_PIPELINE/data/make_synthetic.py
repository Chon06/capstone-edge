"""Sinh bộ dữ liệu GIẢ LẬP giống cấu trúc NEU-DET (ảnh xám 200x200 + XML kiểu Pascal VOC).

CHỈ dùng để chạy thử pipeline khi chưa tải NEU-DET. KHÔNG dùng số liệu độ chính xác
của dữ liệu giả lập trong báo cáo.

    python -m data.make_synthetic --out data/synthetic_neu --per-class 20
"""
import argparse
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

# Tên lớp đúng như trong file XML gốc của NEU-DET (lưu ý 'rolled-in_scale' có dấu gạch ngang)
VOC_NAMES = ["crazing", "inclusion", "patches", "pitted_surface", "rolled-in_scale", "scratches"]
SIZE = 200


def make_image(cls: str, rng: np.random.Generator):
    base = rng.normal(125, 9, (SIZE, SIZE))
    img = Image.fromarray(np.clip(base, 0, 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(1.2))
    d = ImageDraw.Draw(img)
    x1 = int(rng.integers(10, 110)); y1 = int(rng.integers(10, 110))
    x2 = x1 + int(rng.integers(40, 85)); y2 = y1 + int(rng.integers(40, 85))
    if cls == "scratches":
        d.line([(x1, y1), (x2, y2)], fill=235, width=2)
    elif cls == "crazing":
        for _ in range(14):
            a = (int(rng.integers(x1, x2)), int(rng.integers(y1, y2)))
            b = (int(rng.integers(x1, x2)), int(rng.integers(y1, y2)))
            d.line([a, b], fill=60, width=1)
    elif cls == "inclusion":
        d.ellipse([x1, y1, x1 + 30, y1 + 18], fill=40)
        x2, y2 = x1 + 30, y1 + 18
    elif cls == "patches":
        d.rectangle([x1, y1, x2, y2], fill=185)
    elif cls == "pitted_surface":
        for _ in range(25):
            px, py = int(rng.integers(x1, x2)), int(rng.integers(y1, y2))
            d.ellipse([px, py, px + 3, py + 3], fill=50)
    else:  # rolled-in_scale
        d.rectangle([x1, y1, x2, y1 + 22], fill=80)
        y2 = y1 + 22
    img = img.filter(ImageFilter.GaussianBlur(0.6))
    return img, (x1, y1, min(x2, SIZE - 1), min(y2, SIZE - 1))


def write_voc(path: Path, filename: str, cls: str, box):
    xml = (f"<annotation><filename>{filename}</filename>"
           f"<size><width>{SIZE}</width><height>{SIZE}</height><depth>1</depth></size>"
           f"<object><name>{cls}</name><bndbox><xmin>{box[0]}</xmin><ymin>{box[1]}</ymin>"
           f"<xmax>{box[2]}</xmax><ymax>{box[3]}</ymax></bndbox></object></annotation>")
    path.write_text(xml, encoding="utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="data/synthetic_neu")
    ap.add_argument("--per-class", type=int, default=20)
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()
    rng = np.random.default_rng(a.seed)
    out = Path(a.out)
    (out / "images").mkdir(parents=True, exist_ok=True)
    (out / "annotations").mkdir(parents=True, exist_ok=True)
    n = 0
    for cls in VOC_NAMES:
        (out / "images" / cls).mkdir(exist_ok=True)
        for i in range(1, a.per_class + 1):
            img, box = make_image(cls, rng)
            name = f"{cls}_{i}"
            img.save(out / "images" / cls / f"{name}.jpg", quality=95)
            write_voc(out / "annotations" / f"{name}.xml", f"{name}.jpg", cls, box)
            n += 1
    print(f"Đã tạo {n} ảnh giả lập trong {out}")


if __name__ == "__main__":
    main()
