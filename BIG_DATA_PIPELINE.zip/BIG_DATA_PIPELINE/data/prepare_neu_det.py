"""Chuyển NEU-DET (ảnh + XML Pascal VOC) sang định dạng YOLO và chia train/val.

Cách dùng (sau khi tải và giải nén NEU-DET):

    python -m data.prepare_neu_det --src "E:/datasets/NEU-DET" --out data/yolo

Script tự tìm ảnh và file .xml cùng tên ở bất kỳ thư mục con nào nên không phụ thuộc
cấu trúc thư mục cụ thể của bản tải về. Kết quả:

    data/yolo/images/{train,val}/*.jpg
    data/yolo/labels/{train,val}/*.txt
    data/yolo/neu_det.yaml          <- dùng cho huấn luyện YOLO
    data/stream_images/*.jpg        <- ảnh val để "camera giả lập" phát lại
"""
import argparse
import random
import shutil
import xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path

from PIL import Image

from common.imaging import IMAGE_EXTS
from config import CLASSES


def norm_name(name: str) -> str:
    return name.strip().lower().replace("-", "_").replace(" ", "_")


def parse_voc(xml_path: Path, img_path: Path):
    root = ET.parse(xml_path).getroot()
    w = h = None
    size = root.find("size")
    if size is not None and size.findtext("width") and size.findtext("height"):
        w, h = float(size.findtext("width")), float(size.findtext("height"))
    if not w or not h:
        with Image.open(img_path) as im:
            w, h = im.size
    lines = []
    for obj in root.iter("object"):
        cls = norm_name(obj.findtext("name", ""))
        if cls not in CLASSES:
            raise ValueError(f"Lớp lạ '{cls}' trong {xml_path}. Các lớp hợp lệ: {CLASSES}")
        bb = obj.find("bndbox")
        x1, y1 = float(bb.findtext("xmin")), float(bb.findtext("ymin"))
        x2, y2 = float(bb.findtext("xmax")), float(bb.findtext("ymax"))
        x1, x2 = max(0.0, min(x1, x2)), min(w, max(x1, x2))
        y1, y2 = max(0.0, min(y1, y2)), min(h, max(y1, y2))
        if x2 <= x1 or y2 <= y1:
            continue
        cx, cy = (x1 + x2) / 2 / w, (y1 + y2) / 2 / h
        bw, bh = (x2 - x1) / w, (y2 - y1) / h
        lines.append(f"{CLASSES.index(cls)} {cx:.6f} {cy:.6f} {bw:.6f} {bh:.6f}")
    return lines


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True, help="Thư mục NEU-DET đã giải nén")
    ap.add_argument("--out", default="data/yolo")
    ap.add_argument("--stream-dir", default="data/stream_images")
    ap.add_argument("--val-ratio", type=float, default=0.2)
    ap.add_argument("--seed", type=int, default=42)
    a = ap.parse_args()

    src, out = Path(a.src), Path(a.out)
    images = sorted(p for p in src.rglob("*") if p.suffix.lower() in IMAGE_EXTS)
    xmls = {p.stem: p for p in src.rglob("*.xml")}
    pairs = [(img, xmls[img.stem]) for img in images if img.stem in xmls]
    if not pairs:
        raise SystemExit(f"Không tìm thấy cặp ảnh + XML nào trong {src}")
    print(f"Tìm thấy {len(pairs)} cặp ảnh/XML (bỏ qua {len(images) - len(pairs)} ảnh không có XML)")

    # chia train/val theo từng lớp (suy ra từ tên file: crazing_12 -> crazing) để cân bằng
    by_class = defaultdict(list)
    for img, xml in pairs:
        by_class[norm_name(img.stem.rsplit("_", 1)[0])].append((img, xml))
    rng = random.Random(a.seed)
    split = {"train": [], "val": []}
    for cls, items in sorted(by_class.items()):
        rng.shuffle(items)
        n_val = max(1, round(len(items) * a.val_ratio))
        split["val"] += items[:n_val]
        split["train"] += items[n_val:]

    if out.exists():
        shutil.rmtree(out)
    stream = Path(a.stream_dir)
    if stream.exists():
        shutil.rmtree(stream)
    stream.mkdir(parents=True)

    for part, items in split.items():
        (out / "images" / part).mkdir(parents=True)
        (out / "labels" / part).mkdir(parents=True)
        for img, xml in items:
            shutil.copy2(img, out / "images" / part / img.name)
            lines = parse_voc(xml, img)
            (out / "labels" / part / f"{img.stem}.txt").write_text("\n".join(lines), encoding="utf-8")
            if part == "val":
                shutil.copy2(img, stream / img.name)

    names = "\n".join(f"  {i}: {c}" for i, c in enumerate(CLASSES))
    yaml_text = (f"path: {out.resolve().as_posix()}\ntrain: images/train\nval: images/val\nnames:\n{names}\n")
    (out / "neu_det.yaml").write_text(yaml_text, encoding="utf-8")
    print(f"train={len(split['train'])}  val={len(split['val'])}")
    print(f"YAML: {out / 'neu_det.yaml'}")
    print(f"Ảnh cho camera giả lập: {stream} ({len(split['val'])} ảnh)")


if __name__ == "__main__":
    main()
