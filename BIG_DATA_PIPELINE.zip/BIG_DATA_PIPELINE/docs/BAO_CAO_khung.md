# KHUNG BÁO CÁO ĐỀ TÀI

**Tối ưu hóa kiến trúc xử lý phân tầng phục vụ phân tích dữ liệu hình ảnh (Unstructured Data) thời gian thực trong sản xuất công nghiệp**

> Cách dùng: các mục `[ĐIỀN: ...]` là số liệu/nội dung bạn lấy từ kết quả chạy thật (`results/*.csv`, `results/figures/*.png`).
> Khung này **không chứa số liệu**: không điền số nào chưa đo thật.

## 1. Mở đầu
- 1.1 Bối cảnh: Công nghiệp 4.0, kiểm định chất lượng bằng camera, dữ liệu ảnh nặng và liên tục.
- 1.2 Khoảng trống nghiên cứu (theo Kretzer, Benitti, Siqueira — *Challenges and Opportunities in Big Data Analytics for Industry 4.0: A Systematic Evaluation of Current Architectures*, IEEE Access): hệ thống BDA xử lý tốt dữ liệu có cấu trúc, còn dữ liệu phi cấu trúc (ảnh) thì nghẽn băng thông, độ trễ cao, rớt khung. [ĐIỀN: trích dẫn trang/mục cụ thể từ bài báo]
- 1.3 Mục tiêu và câu hỏi nghiên cứu:
  - Q1: Kiến trúc 3 tầng (Edge – Kafka – Spark/MinIO) có đạt độ trễ mục tiêu mà không rớt khung không?
  - Q2: Buffer, số worker, mức nén JPEG ảnh hưởng thế nào tới độ trễ, thông lượng, độ chính xác?
- 1.4 Phạm vi và giới hạn (xem mục 6).

## 2. Cơ sở lý thuyết và công trình liên quan
Edge computing; Kafka (topic, partition, consumer group, back-pressure); Spark Structured Streaming (micro-batch); Data Lake/MinIO; YOLO. [ĐIỀN: tài liệu tham khảo]

## 3. Kiến trúc đề xuất
- Sơ đồ 3 tầng (Task 1.2): [CHÈN HÌNH]
- Tầng Edge: camera giả lập, YOLOv8-nano/bộ lọc classic, nén JPEG, gói tin JSON (schema v1.0 — Task 1.4, xem `schemas/`).
- Tầng Hàng đợi: Kafka 1 broker, topic `defect.frames`, 3 partition, replication 1; consumer có buffer giới hạn và worker song song.
- Tầng Phân tích & Data Lake: Spark Structured Streaming, MinIO (2 bucket), phân tích mức độ nghiêm trọng và cảnh báo theo camera.
- Hai đường dữ liệu: **đường nhanh** (Edge→Kafka→consumer) và **đường phân tích sâu** (Kafka→Spark→MinIO).
- Định nghĩa các thời điểm đo: `ts_capture_ms`, `ts_edge_done_ms`, thời điểm consumer nhận/xử lý xong; công thức e2e, transit, bufwait.

## 4. Thiết lập thực nghiệm
| Hạng mục | Giá trị |
|---|---|
| Máy chạy thí nghiệm | [ĐIỀN: CPU, số nhân, RAM, hệ điều hành] |
| Giới hạn Docker Desktop/WSL2 | [ĐIỀN: CPU, RAM] |
| Dữ liệu | NEU-DET, 1800 ảnh 200×200, 6 lớp; chia train/val 80/20 (seed 42) |
| Mô hình Edge | YOLOv8n, imgsz 224, [ĐIỀN: epoch], mAP50 = [ĐIỀN] |
| Số luồng Edge giả lập | [ĐIỀN: --yolo-threads] |
| Phiên bản phần mềm | Kafka cp-kafka 7.4.0, MinIO mirror 2025-09-07, Spark 3.5.3, Python [ĐIỀN] |
| Quy trình đo | mỗi cấu hình lặp 3 lần, báo cáo trung bình ± độ lệch chuẩn; 500 khung/lần |

Chỉ số: độ trễ e2e (mean, p50, p95, p99, max), thông lượng FPS (producer/consumer), Zero Frame Drop, CPU/RAM, băng thông tầng ứng dụng.

## 5. Kết quả
### 5.1 Độ chính xác của Edge
- mAP50 / mAP50-95 của YOLOv8n trên tập val: [ĐIỀN]. Độ trễ suy luận Edge: mean [ĐIỀN] ms, p95 [ĐIỀN] ms so với mục tiêu 15 ms.
- Bảng so sánh `classic` và `yolo`: tỉ lệ khung được gắn NG, thời gian xử lý. [ĐIỀN]

### 5.2 Thử tải 1000+ ảnh (Task 3.3)
Gửi [ĐIỀN] / nhận [ĐIỀN] / mất [ĐIỀN] / trùng [ĐIỀN]; Zero Frame Drop: [ĐIỀN]. (`python -m bench.load_test`)

### 5.3 Độ trễ đường nhanh (Task 5.2)
Bảng và hình `fig_fps_saturation.png`: FPS tối đa không rớt khung = [ĐIỀN]; độ trễ p95 tại FPS vận hành = [ĐIỀN] ms (mục tiêu < 100 ms). Phân rã độ trễ: Edge [ĐIỀN] + Kafka [ĐIỀN] + buffer [ĐIỀN] + xử lý [ĐIỀN].

### 5.4 Độ trễ đường Spark
Độ trễ e2e tại Spark (từ `defect-analysis/summary/*.json`): mean [ĐIỀN], p95 [ĐIỀN] ms; giải thích ảnh hưởng của micro-batch (trigger [ĐIỀN] giây).

### 5.5 Tối ưu cấu hình (Task 5.3)
- Mức nén JPEG: `fig_jpeg_latency_size.png`, `fig_jpeg_accuracy.png` → mức nén cân bằng tốt nhất: [ĐIỀN]. Lập luận bằng số: giảm [ĐIỀN]% dung lượng đổi lấy giảm [ĐIỀN] điểm mAP.
- Số worker: `fig_workers.png` → số worker tối ưu [ĐIỀN] (điểm mà thêm worker không còn giảm độ trễ).
- Kích thước buffer: `fig_buffer.png` → buffer quá lớn làm tăng độ trễ chờ ([ĐIỀN]), quá nhỏ gây back-pressure sớm. Giá trị đề xuất: [ĐIỀN].
- **Cấu hình tối ưu đề xuất** (đóng góp chính): jpeg_quality=[ĐIỀN], workers=[ĐIỀN], buffer=[ĐIỀN], partitions=[ĐIỀN].

### 5.6 Tài nguyên
CPU/RAM theo tải (`fig_fps_cpu.png`, và container nếu dùng `--docker-stats`); băng thông tầng ứng dụng [ĐIỀN] Mbps.

## 6. Thảo luận và hạn chế
- Edge giả lập trên laptop, không phải Raspberry Pi/Jetson Nano → số đo Edge chỉ mang tính tương đối.
- Hệ thống chạy trên một máy, 1 broker, replication factor 1 → không đánh giá được độ sẵn sàng cao và độ trễ mạng thật.
- NEU-DET không có ảnh không lỗi → không đo được độ chính xác OK/NG.
- Spark micro-batch không đạt thời gian thực mức mili giây; đường nhanh đảm nhận thời gian thực, Spark làm phân tích bất đồng bộ.
- Bộ lọc `classic` bỏ sót lỗi vùng lớn, tương phản thấp.
- MinIO dùng bản sao bên thứ ba vì image chính thức đã bị gỡ.
- Phạm vi dữ liệu: một bộ dữ liệu công khai, chưa kiểm chứng trên dây chuyền thật.

## 7. Kết luận và hướng phát triển
Trả lời Q1, Q2 bằng số liệu mục 5. Hướng phát triển: chạy trên thiết bị biên thật, cụm Kafka nhiều broker, dữ liệu nhà máy thật, so sánh với RabbitMQ.

## Tài liệu tham khảo
- Kretzer, A. R., Benitti, F. B. V., Siqueira, F. *Challenges and Opportunities in Big Data Analytics for Industry 4.0: A Systematic Evaluation of Current Architectures.* IEEE Access. [ĐIỀN: năm, tập, trang, DOI]
- [ĐIỀN: NEU-DET (Song & Yan), YOLOv8/Ultralytics, Kafka, Spark, MinIO]

## Phụ lục
- Schema gói tin: `schemas/frame_message_v1.schema.json`
- File kết quả thô: `results/exp_*.csv`
- Mã nguồn và hướng dẫn chạy lại: `README.md`
